"""Integração de IA — ARQUIVO ÚNICO E CENTRALIZADO.

Toda comunicação com a Groq (modelo DeepSeek) passa por aqui. Para trocar de
modelo ou provedor no futuro, basta mexer neste arquivo:
  - GROQ_API_KEY e GROQ_MODEL vêm do .env (variáveis de ambiente).
  - Todas as outras camadas do sistema só chamam as funções públicas
    abaixo (gerar_plano_inicial, responder_chat, etc.) e nunca fazem
    requisição HTTP diretamente.

IMPORTANTE (regra do projeto): a IA nunca calcula valores financeiros.
Ela sempre recebe números já calculados pelo `finance_service` e apenas os
explica/comenta em linguagem natural. Isso evita alucinações em matemática.
"""
import logging
import requests
from flask import current_app

logger = logging.getLogger("finia.ai")

GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

SYSTEM_PROMPT_BASE = (
    "Você é o Porquinho IA, assistente financeiro do app FinIA. Fale em "
    "português do Brasil, em tom acolhedor, direto e confiante — como um "
    "amigo que manja muito de dinheiro e não fica só narrando números, dá "
    "conselho de verdade. Nunca invente números: use apenas os valores "
    "fornecidos no contexto. Nunca faça contas novas, apenas interprete e "
    "explique os valores que já vêm calculados. Sempre que fizer sentido, "
    "termine com uma sugestão prática e específica (não genérica) baseada "
    "nos números reais — por exemplo, se houver dívida ativa, priorize "
    "comentar isso; se o vale-alimentação estiver quase no fim, avise. "
    "Seja breve (no máximo 4-5 frases, a menos que o usuário peça mais "
    "detalhes)."
)


def _config():
    api_key = current_app.config.get("GROQ_API_KEY")
    model = current_app.config.get("GROQ_MODEL")
    return api_key, model


def _chamar_ia(mensagens, *, temperature=0.6, max_tokens=400, fallback: str):
    """Faz a chamada HTTP à Groq. Em qualquer falha, retorna `fallback` em vez
    de quebrar a experiência do usuário (o app deve funcionar mesmo se a IA
    estiver fora do ar — os cálculos continuam corretos, só a narrativa muda)."""
    api_key, model = _config()
    if not api_key:
        logger.warning("GROQ_API_KEY não configurada — usando resposta padrão.")
        return fallback

    try:
        resp = requests.post(
            GROQ_ENDPOINT,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": mensagens,
                "temperature": temperature,
                "max_tokens": max_tokens,
            },
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
        texto = data["choices"][0]["message"]["content"].strip()
        return texto or fallback
    except requests.exceptions.RequestException as exc:
        logger.error("Falha ao chamar a Groq: %s", exc)
        return fallback
    except (KeyError, IndexError, ValueError) as exc:
        logger.error("Resposta inesperada da Groq: %s", exc)
        return fallback


def gerar_plano_inicial(perfil: dict, calculo: dict, objetivo_texto_livre: str = "") -> str:
    """Narra o plano recém-calculado, usando a resposta aberta do onboarding
    para personalizar o tom (ex.: citar o motivo pessoal do objetivo)."""
    contexto = (
        f"Nome: {perfil.get('nome')}\n"
        f"Objetivo: {perfil.get('objetivo')} em {perfil.get('prazo')} meses\n"
        f"Relato do usuário sobre o objetivo: \"{objetivo_texto_livre or 'não informado'}\"\n"
        f"Entradas mensais: R$ {calculo['entradas']:.2f}\n"
        f"Contas fixas: R$ {calculo['contas_fixas']:.2f}\n"
        f"Reserva sugerida: R$ {calculo['reserva_sugerida']:.2f}\n"
        f"Meta mensal de economia: R$ {calculo['meta_mensal']:.2f}\n"
        f"Disponível para lazer: R$ {calculo['disponivel_lazer']:.2f}\n"
    )
    mensagens = [
        {"role": "system", "content": SYSTEM_PROMPT_BASE},
        {"role": "user", "content": (
            "Crie uma mensagem de boas-vindas ao plano financeiro recém-criado, "
            f"usando estes dados:\n{contexto}\nSeja específico usando os valores acima."
        )},
    ]
    fallback = (
        f"Prontinho, {perfil.get('nome', 'tudo certo')}! Montei seu plano para "
        f"\"{perfil.get('objetivo')}\": reserve R$ {calculo['reserva_sugerida']:.2f}, "
        f"economize R$ {calculo['meta_mensal']:.2f} por mês e você ainda tem "
        f"R$ {calculo['disponivel_lazer']:.2f} livres para o seu lazer."
    )
    return _chamar_ia(mensagens, fallback=fallback)


def responder_chat(mensagem_usuario: str, contexto: dict, historico: list) -> str:
    """Responde uma pergunta do usuário no chat, com contexto financeiro atual."""
    contexto_texto = (
        f"Saldo disponível: R$ {contexto.get('saldo', 0):.2f}\n"
        f"Economizado este mês: R$ {contexto.get('economizado', 0):.2f}\n"
        f"Objetivo: {contexto.get('objetivo', 'não definido')} "
        f"(faltam R$ {contexto.get('falta_meta', 0):.2f})\n"
        f"Gastos por impulso este mês: R$ {contexto.get('gastos_impulso_mes', 0):.2f}\n"
        f"Total em dívidas ativas: R$ {contexto.get('dividas_total', 0):.2f}\n"
        f"Vale-alimentação restante este mês: R$ {contexto.get('alimentacao_restante', 0):.2f}\n"
    )
    mensagens = [{"role": "system", "content": SYSTEM_PROMPT_BASE + "\n\nContexto financeiro atual:\n" + contexto_texto}]
    for h in historico[-8:]:
        role = "assistant" if h.get("autor") == "ia" else "user"
        mensagens.append({"role": role, "content": h.get("mensagem", "")})
    mensagens.append({"role": "user", "content": mensagem_usuario})

    fallback = (
        "Estou com uma instabilidade para pensar agora, mas seus dados estão "
        "seguros. Tente novamente em instantes — enquanto isso, dá uma olhada "
        "no seu painel para ver o resumo mais recente."
    )
    return _chamar_ia(mensagens, fallback=fallback)


def explicar_gastos_impulsivos(total_mes: float, media_anterior: float, itens: list) -> str:
    lista = "; ".join(f"{i['descricao']} (R$ {i['valor']:.2f})" for i in itens[:5]) or "nenhum registrado ainda"
    contexto = (
        f"Total gasto por impulso este mês: R$ {total_mes:.2f}\n"
        f"Média dos meses anteriores: R$ {media_anterior:.2f}\n"
        f"Últimas compras por impulso: {lista}\n"
    )
    mensagens = [
        {"role": "system", "content": SYSTEM_PROMPT_BASE},
        {"role": "user", "content": (
            "Explique de forma gentil como esses gastos por impulso afetam o "
            f"objetivo do usuário e dê uma sugestão prática:\n{contexto}"
        )},
    ]
    metade = total_mes / 2
    fallback = (
        f"Você gastou R$ {total_mes:.2f} em compras por impulso este mês. "
        f"Se reduzir esse valor pela metade, pode guardar mais R$ {metade:.2f} "
        "rumo ao seu objetivo."
    )
    return _chamar_ia(mensagens, fallback=fallback)


def gerar_dica_dashboard(contexto: dict) -> str:
    contexto_texto = (
        f"Nome: {contexto.get('nome')}\n"
        f"Economizado: R$ {contexto.get('economizado', 0):.2f}\n"
        f"Objetivo: {contexto.get('objetivo')}\n"
        f"Progresso da meta: {contexto.get('meta_percent', 0)}%\n"
        f"Total em dívidas ativas: R$ {contexto.get('dividas_total', 0):.2f}\n"
        f"Vale-alimentação restante este mês: R$ {contexto.get('alimentacao_restante', 0):.2f}\n"
    )
    mensagens = [
        {"role": "system", "content": SYSTEM_PROMPT_BASE},
        {"role": "user", "content": f"Gere uma única frase motivacional curta e específica para o painel principal (priorize mencionar dívida ativa ou vale-alimentação acabando, se houver):\n{contexto_texto}"},
    ]
    fallback = (
        f"{contexto.get('nome', 'Você')} já está {contexto.get('meta_percent', 0)}% "
        f"do caminho até \"{contexto.get('objetivo')}\". Continue assim!"
    )
    return _chamar_ia(mensagens, max_tokens=120, fallback=fallback)
