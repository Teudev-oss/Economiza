from flask import Blueprint, request, jsonify, g
from models.schemas import validate_gasto_impulso, ValidationError
from services import impulso_service
from api import ai_service
from utils.decorators import login_required

bp = Blueprint("impulso", __name__, url_prefix="/api/gastos-impulso")


@bp.get("")
@login_required
def listar():
    resumo = impulso_service.resumo_impulso(g.usuario["id"])
    mensagem_ia = ai_service.explicar_gastos_impulsivos(
        resumo["total_mes_atual"], resumo["media_meses_anteriores"], resumo["itens_recentes"]
    )
    return jsonify({"ok": True, **resumo, "mensagem_ia": mensagem_ia})


@bp.post("")
@login_required
def registrar():
    try:
        dados = validate_gasto_impulso(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    item = impulso_service.registrar_gasto_impulso(
        g.usuario["id"], dados["descricao"], dados["valor"], dados["gatilho"]
    )
    return jsonify({"ok": True, "item": item})
