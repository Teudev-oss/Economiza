from flask import Blueprint, request, jsonify, g
from models.schemas import validate_gasto, ValidationError
from services import gastos_service
from utils.decorators import login_required

bp = Blueprint("gastos", __name__, url_prefix="/api/gastos")


@bp.get("")
@login_required
def listar():
    return jsonify({"ok": True, "gastos": gastos_service.listar_gastos(g.usuario["id"])})


@bp.post("")
@login_required
def registrar():
    try:
        dados = validate_gasto(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    gasto, texto_limpo, categoria = gastos_service.registrar_gasto(g.usuario["id"], dados["texto"])
    if gasto is None:
        return jsonify({
            "ok": False,
            "erro": "Não consegui identificar um valor em reais no texto. Tente incluir o número (ex.: 'pizza 45').",
            "categoria_sugerida": categoria,
        }), 422

    return jsonify({"ok": True, "gasto": gasto})
