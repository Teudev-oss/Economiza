from flask import Blueprint, request, jsonify, g
from datetime import date, timedelta
from models.schemas import validate_troca_senha, ValidationError
from services import auth_service, resumo_service, plano_service, gastos_service
from utils.decorators import login_required

bp = Blueprint("perfil", __name__, url_prefix="/api/perfil")


@bp.get("")
@login_required
def obter():
    u = g.usuario
    dashboard = resumo_service.montar_dashboard(u["id"], u["nome"])
    objetivo = plano_service.obter_objetivo_ativo(u["id"])

    gastos = gastos_service.listar_gastos(u["id"], limite=200)
    hoje = date.today()
    dias_com_registro = set()
    for gasto in gastos:
        try:
            d = date.fromisoformat(gasto["data_gasto"])
        except (KeyError, ValueError, TypeError):
            continue
        if (hoje - d).days <= 30:
            dias_com_registro.add(d)

    return jsonify({
        "ok": True,
        "nome": u["nome"],
        "criado_em": u["created_at"],
        "is_admin": bool(u.get("is_admin")),
        "objetivo": objetivo["titulo"] if objetivo else None,
        "pontuacao": dashboard["pontuacao"],
        "objetivos_ativos": 1 if objetivo else 0,
        "dias_ativos_30d": len(dias_com_registro),
    })


@bp.post("/senha")
@login_required
def trocar_senha():
    try:
        dados = validate_troca_senha(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    try:
        auth_service.trocar_senha(g.usuario["id"], dados["senha_atual"], dados["senha_nova"])
    except ValueError as e:
        return jsonify({"ok": False, "erro": str(e)}), 400

    return jsonify({"ok": True})
