from flask import Blueprint, request, jsonify, g
from models.schemas import validate_chat_mensagem, ValidationError
from services import resumo_service, chat_service, impulso_service
from utils.security import sanitize_text
from api import ai_service
from utils.decorators import login_required

bp = Blueprint("chat", __name__, url_prefix="/api/chat")


@bp.get("/historico")
@login_required
def historico():
    return jsonify({"ok": True, "mensagens": chat_service.listar_historico(g.usuario["id"])})


@bp.post("")
@login_required
def enviar():
    try:
        dados = validate_chat_mensagem(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    mensagem_limpa = sanitize_text(dados["mensagem"])
    chat_service.salvar_mensagem(g.usuario["id"], "user", mensagem_limpa)

    dashboard = resumo_service.montar_dashboard(g.usuario["id"], g.usuario["nome"])
    objetivo = dashboard["objetivo"]
    resumo_impulso = impulso_service.resumo_impulso(g.usuario["id"])
    contexto = {
        "saldo": dashboard["saldo"],
        "economizado": dashboard["economizado"],
        "objetivo": objetivo["titulo"],
        "falta_meta": max((objetivo["valor_meta"] or 0) - (objetivo["valor_atual"] or 0), 0),
        "gastos_impulso_mes": resumo_impulso["total_mes_atual"],
        "dividas_total": dashboard["dividas"]["total_ativo"],
        "alimentacao_restante": dashboard["alimentacao"]["restante"],
    }
    historico_atual = chat_service.listar_historico(g.usuario["id"], limite=20)
    resposta = ai_service.responder_chat(mensagem_limpa, contexto, historico_atual)

    chat_service.salvar_mensagem(g.usuario["id"], "ia", resposta)
    return jsonify({"ok": True, "resposta": resposta})
