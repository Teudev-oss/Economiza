"""Serve as páginas HTML nas mesmas URLs relativas que o front-end já usa,
para não quebrar nenhum link/redirecionamento existente no JS original.
"""
from flask import Blueprint, render_template, redirect, url_for, g
from utils.decorators import login_required, admin_required

bp = Blueprint("pages", __name__)


@bp.get("/login.html")
def login_page():
    return render_template("login.html")


@bp.get("/")
@login_required
def index_page():
    if not g.usuario.get("onboarding_done"):
        return redirect(url_for("pages.onboarding_page"))
    return render_template("index.html")


@bp.get("/adm.html")
@login_required
@admin_required
def admin_page():
    return render_template("adm.html")


@bp.get("/pages/onboarding.html")
@login_required
def onboarding_page():
    return render_template("pages/onboarding.html")


@bp.get("/pages/registrar-gasto.html")
@login_required
def registrar_gasto_page():
    return render_template("pages/registrar-gasto.html")


@bp.get("/pages/meu-plano.html")
@login_required
def meu_plano_page():
    return render_template("pages/meu-plano.html")


@bp.get("/pages/evolucao.html")
@login_required
def evolucao_page():
    return render_template("pages/evolucao.html")


@bp.get("/pages/chat.html")
@login_required
def chat_page():
    return render_template("pages/chat.html")


@bp.get("/pages/perfil.html")
@login_required
def perfil_page():
    return render_template("pages/perfil.html")


@bp.get("/pages/gastos-impulso.html")
@login_required
def gastos_impulso_page():
    return render_template("pages/gastos-impulso.html")
