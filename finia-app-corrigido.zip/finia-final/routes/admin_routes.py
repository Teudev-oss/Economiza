from flask import Blueprint, request, jsonify, g
from models.schemas import validate_novo_codigo, ValidationError
from services import admin_service
from utils.decorators import login_required, admin_required

bp = Blueprint("admin", __name__, url_prefix="/api/admin")


@bp.get("/resumo")
@login_required
@admin_required
def resumo():
    online, total = admin_service.contar_usuarios_online()
    return jsonify({"ok": True, "total_usuarios": total, "online": online})


@bp.get("/usuarios")
@login_required
@admin_required
def usuarios():
    busca = request.args.get("busca", "")
    lista = admin_service.listar_usuarios(busca)
    for u in lista:
        u["contadores"] = admin_service.contagem_gastos_e_objetivos(u["id"])
    return jsonify({"ok": True, "usuarios": lista})


@bp.get("/logs")
@login_required
@admin_required
def logs():
    return jsonify({"ok": True, "logs": admin_service.listar_logs()})


@bp.get("/codigos")
@login_required
@admin_required
def codigos():
    return jsonify({"ok": True, "codigos": admin_service.listar_codigos()})


@bp.post("/codigos")
@login_required
@admin_required
def criar_codigo():
    try:
        dados = validate_novo_codigo(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400
    try:
        codigo = admin_service.criar_codigo(
            max_usos=dados["max_usos"], observacao=dados["observacao"],
            codigo=dados["codigo"], criado_por=g.usuario["nome"],
        )
    except ValueError as e:
        return jsonify({"ok": False, "erro": str(e)}), 400
    return jsonify({"ok": True, "codigo": codigo})


@bp.post("/codigos/<codigo_id>/revogar")
@login_required
@admin_required
def revogar_codigo(codigo_id):
    admin_service.revogar_codigo(codigo_id)
    return jsonify({"ok": True})
