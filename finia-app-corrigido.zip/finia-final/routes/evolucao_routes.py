from flask import Blueprint, jsonify, g
from services import resumo_service
from utils.decorators import login_required

bp = Blueprint("evolucao", __name__, url_prefix="/api/evolucao")


@bp.get("")
@login_required
def evolucao():
    dados = resumo_service.montar_evolucao(g.usuario["id"])
    return jsonify({"ok": True, **dados})
