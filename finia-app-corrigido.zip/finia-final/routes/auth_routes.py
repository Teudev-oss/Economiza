"""Rotas de autenticação: cadastro, login, logout, recuperação de sessão."""
from flask import Blueprint, request, jsonify, session, g, current_app
from models.schemas import validate_registro, validate_login, ValidationError
from services import auth_service
from utils.decorators import login_required
from extensions import limiter

bp = Blueprint("auth", __name__, url_prefix="/api/auth")


def _client_ip():
    return request.headers.get("X-Forwarded-For", request.remote_addr or "")


@bp.post("/registrar")
@limiter.limit("8 per hour")
def registrar():
    try:
        dados = validate_registro(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    is_admin = bool(
        current_app.config.get("BOOTSTRAP_ADMIN_NOME")
        and dados["nome"].strip().lower() == current_app.config["BOOTSTRAP_ADMIN_NOME"].strip().lower()
    )

    try:
        usuario = auth_service.criar_usuario(dados["nome"], dados["senha"], dados["codigo_acesso"], is_admin=is_admin)
    except ValueError as e:
        return jsonify({"ok": False, "erro": str(e)}), 400

    session.clear()
    session.permanent = True
    session["usuario_id"] = usuario["id"]
    session["session_token"] = usuario["session_token"]

    auth_service.registrar_log_acesso(usuario["id"], "cadastro", _client_ip(), request.headers.get("User-Agent"))

    return jsonify({"ok": True, "onboarding_done": False, "nome": usuario["nome"]})


@bp.post("/login")
@limiter.limit("10 per minute")
def login():
    try:
        dados = validate_login(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    usuario, token = auth_service.autenticar(dados["nome"], dados["senha"])
    if not usuario:
        auth_service.registrar_log_acesso(None, "login_falha", _client_ip(), request.headers.get("User-Agent"))
        return jsonify({"ok": False, "erro": "Nome ou senha incorretos."}), 401

    session.clear()
    session.permanent = True
    session["usuario_id"] = usuario["id"]
    session["session_token"] = token

    auth_service.registrar_log_acesso(usuario["id"], "login_sucesso", _client_ip(), request.headers.get("User-Agent"))

    return jsonify({
        "ok": True,
        "onboarding_done": bool(usuario.get("onboarding_done")),
        "nome": usuario["nome"],
        "is_admin": bool(usuario.get("is_admin")),
    })


@bp.post("/logout")
@login_required
def logout():
    auth_service.invalidar_sessao(g.usuario["id"])
    auth_service.registrar_log_acesso(g.usuario["id"], "logout", _client_ip(), request.headers.get("User-Agent"))
    session.clear()
    return jsonify({"ok": True})


@bp.get("/me")
def me():
    """Usado no carregamento de qualquer página para recuperar a sessão."""
    usuario_id = session.get("usuario_id")
    session_token = session.get("session_token")
    if not usuario_id:
        return jsonify({"ok": True, "autenticado": False})

    usuario = auth_service.get_usuario_by_id(usuario_id)
    if not usuario or usuario.get("session_token") != session_token or usuario.get("status") != "ativo":
        session.clear()
        return jsonify({"ok": True, "autenticado": False})

    return jsonify({
        "ok": True,
        "autenticado": True,
        "nome": usuario["nome"],
        "onboarding_done": bool(usuario.get("onboarding_done")),
        "is_admin": bool(usuario.get("is_admin")),
    })
