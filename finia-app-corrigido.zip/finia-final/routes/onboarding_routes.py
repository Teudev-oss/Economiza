from flask import Blueprint, request, jsonify, g
from models.schemas import validate_onboarding, ValidationError
from services import auth_service, plano_service
from utils.decorators import login_required

bp = Blueprint("onboarding", __name__, url_prefix="/api/onboarding")


@bp.post("")
@login_required
def concluir_onboarding():
    try:
        dados = validate_onboarding(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    resultado = plano_service.criar_plano_onboarding(g.usuario["id"], dados)
    auth_service.marcar_onboarding_concluido(g.usuario["id"])

    return jsonify({
        "ok": True,
        "calculo": resultado["calculo"],
        "mensagem_ia": resultado["mensagem_ia"],
    })
