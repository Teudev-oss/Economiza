from flask import Blueprint, request, jsonify, g
from models.schemas import validate_divida, ValidationError
from services import dividas_service
from utils.decorators import login_required

bp = Blueprint("dividas", __name__, url_prefix="/api/dividas")


@bp.get("")
@login_required
def listar():
    itens = dividas_service.listar_dividas(g.usuario["id"])
    total_ativo = dividas_service.total_dividas_ativas(g.usuario["id"])
    return jsonify({"ok": True, "itens": itens, "total_ativo": total_ativo})


@bp.post("")
@login_required
def criar():
    try:
        dados = validate_divida(request.get_json(silent=True) or {})
    except ValidationError as e:
        return jsonify({"ok": False, "erros": e.errors}), 400

    item = dividas_service.criar_divida(g.usuario["id"], dados["nome"], dados["valor"])
    if not item:
        return jsonify({"ok": False, "erro": "Não foi possível registrar a dívida."}), 500
    return jsonify({"ok": True, "item": item})


@bp.post("/<divida_id>/quitar")
@login_required
def quitar(divida_id):
    ok = dividas_service.quitar_divida(g.usuario["id"], divida_id)
    if not ok:
        return jsonify({"ok": False, "erro": "Dívida não encontrada."}), 404
    return jsonify({"ok": True})


@bp.delete("/<divida_id>")
@login_required
def excluir(divida_id):
    ok = dividas_service.excluir_divida(g.usuario["id"], divida_id)
    if not ok:
        return jsonify({"ok": False, "erro": "Dívida não encontrada."}), 404
    return jsonify({"ok": True})
