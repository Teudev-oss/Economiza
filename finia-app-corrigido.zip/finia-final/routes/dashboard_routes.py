from flask import Blueprint, jsonify, g
from services import resumo_service
from utils.decorators import login_required

bp = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")


@bp.get("")
@login_required
def dashboard():
    dados = resumo_service.montar_dashboard(g.usuario["id"], g.usuario["nome"])
    return jsonify({"ok": True, **dados})
