from flask import Blueprint, request, jsonify, g
from services import plano_service, resumo_service
from utils.decorators import login_required

bp = Blueprint("plano", __name__, url_prefix="/api/plano")


@bp.get("")
@login_required
def obter():
    plano = plano_service.obter_plano_atual(g.usuario["id"])
    objetivo = plano_service.obter_objetivo_ativo(g.usuario["id"])
    if not plano:
        return jsonify({"ok": True, "plano": None, "objetivo": None})
    # "disponivel_economia" no plano é um valor fixo definido na criação do
    # plano (igual à meta), não o que a pessoa realmente guardou. Buscamos o
    # progresso real (baseado nos gastos registrados) pra não mostrar sempre 100%.
    dashboard = resumo_service.montar_dashboard(g.usuario["id"], g.usuario["nome"])
    return jsonify({"ok": True, "plano": plano, "objetivo": objetivo, "economizado_real": dashboard["economizado"]})


@bp.post("/checklist")
@login_required
def checklist():
    body = request.get_json(silent=True) or {}
    plano_id = body.get("plano_id")
    item_id = body.get("item_id")
    done = bool(body.get("done"))
    if not plano_id or not item_id:
        return jsonify({"ok": False, "erro": "Dados incompletos."}), 400

    checklist = plano_service.atualizar_checklist(g.usuario["id"], plano_id, item_id, done)
    if checklist is None:
        return jsonify({"ok": False, "erro": "Plano não encontrado."}), 404
    return jsonify({"ok": True, "checklist": checklist})
