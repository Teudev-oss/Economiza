"""Instâncias únicas de extensões Flask, compartilhadas entre app.py e as rotas."""
from flask_wtf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

csrf = CSRFProtect()
limiter = Limiter(key_func=get_remote_address)
