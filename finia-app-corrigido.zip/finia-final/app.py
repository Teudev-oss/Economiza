"""Ponto de entrada da aplicação FinIA (Flask + Supabase + Groq/DeepSeek)."""
import logging
from flask import Flask, jsonify, request
from config import Config
from extensions import csrf, limiter

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


def create_app():
    app = Flask(__name__, static_folder="static", static_url_path="", template_folder="templates")
    app.config.from_object(Config)

    csrf.init_app(app)
    limiter.init_app(app)

    # --- Blueprints ---
    from routes import (
        auth_routes, onboarding_routes, dashboard_routes, gastos_routes,
        impulso_routes, plano_routes, evolucao_routes, chat_routes,
        perfil_routes, admin_routes, pages_routes, dividas_routes,
    )
    app.register_blueprint(auth_routes.bp)
    app.register_blueprint(onboarding_routes.bp)
    app.register_blueprint(dashboard_routes.bp)
    app.register_blueprint(gastos_routes.bp)
    app.register_blueprint(impulso_routes.bp)
    app.register_blueprint(plano_routes.bp)
    app.register_blueprint(evolucao_routes.bp)
    app.register_blueprint(chat_routes.bp)
    app.register_blueprint(perfil_routes.bp)
    app.register_blueprint(admin_routes.bp)
    app.register_blueprint(pages_routes.bp)
    app.register_blueprint(dividas_routes.bp)

    _registrar_cabecalhos_seguranca(app)
    _registrar_error_handlers(app)
    _bootstrap_codigo_acesso(app)

    return app


def _registrar_cabecalhos_seguranca(app):
    @app.after_request
    def set_security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        # CSP permissiva o suficiente para as fontes do Google já usadas pelo front-end original.
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data:; "
            "script-src 'self'; "
            "connect-src 'self';"
        )
        return resp


def _registrar_error_handlers(app):
    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "erro": "Rota não encontrada."}), 404
        return jsonify({"ok": False, "erro": "Página não encontrada."}), 404

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("Erro interno inesperado")
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "erro": "Erro interno. Tente novamente em instantes."}), 500
        return jsonify({"ok": False, "erro": "Erro interno."}), 500

    @app.errorhandler(429)
    def rate_limited(e):
        return jsonify({"ok": False, "erro": "Muitas tentativas. Aguarde um momento e tente novamente."}), 429

    from flask_wtf.csrf import CSRFError

    @app.errorhandler(CSRFError)
    def csrf_error(e):
        return jsonify({"ok": False, "erro": "Sessão de segurança expirada, recarregue a página."}), 400


def _bootstrap_codigo_acesso(app):
    """Garante que o código de acesso inicial (BOOTSTRAP_ACCESS_CODE) exista,
    útil apenas para o primeiro deploy — nunca sobrescreve nada existente."""
    codigo = app.config.get("BOOTSTRAP_ACCESS_CODE")
    if not codigo:
        return
    with app.app_context():
        try:
            from services import auth_service, admin_service
            if not auth_service.validar_codigo_acesso(codigo):
                existentes = [c["codigo"] for c in admin_service.listar_codigos()]
                if codigo not in existentes:
                    admin_service.criar_codigo(max_usos=50, observacao="Código inicial (bootstrap)", codigo=codigo)
                    app.logger.info("Código de acesso inicial '%s' criado.", codigo)
        except Exception as exc:  # noqa: BLE001
            app.logger.warning("Não foi possível preparar o código de acesso inicial: %s", exc)


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=app.config["DEBUG"])
