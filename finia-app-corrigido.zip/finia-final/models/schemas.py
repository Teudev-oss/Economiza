"""Validação de dados de entrada.

Sem depender de bibliotecas pesadas: validamos manualmente para termos
controle total das mensagens de erro e evitar aceitar campos inesperados.
"""
import re


class ValidationError(Exception):
    def __init__(self, errors):
        if isinstance(errors, str):
            errors = {"_erro": errors}
        self.errors = errors
        super().__init__(str(errors))


NOME_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ0-9 '\-]{2,60}$")
CODIGO_RE = re.compile(r"^[A-Za-z0-9\-]{4,32}$")


def _s(value):
    return (value or "").strip() if isinstance(value, str) else ""


def validate_registro(data: dict):
    errors = {}
    nome = _s(data.get("nome"))
    senha = data.get("senha") or ""
    codigo = _s(data.get("codigo_acesso")).upper()

    if not nome or not NOME_RE.match(nome):
        errors["nome"] = "Informe um nome válido (2-60 caracteres)."
    if not isinstance(senha, str) or len(senha) < 8:
        errors["senha"] = "A senha deve ter pelo menos 8 caracteres."
    elif len(senha) > 128:
        errors["senha"] = "Senha muito longa."
    if not codigo or not CODIGO_RE.match(codigo):
        errors["codigo_acesso"] = "Código de acesso inválido."

    if errors:
        raise ValidationError(errors)
    return {"nome": nome, "senha": senha, "codigo_acesso": codigo}


def validate_login(data: dict):
    errors = {}
    nome = _s(data.get("nome"))
    senha = data.get("senha") or ""
    if not nome:
        errors["nome"] = "Informe seu nome."
    if not senha:
        errors["senha"] = "Informe sua senha."
    if errors:
        raise ValidationError(errors)
    return {"nome": nome, "senha": senha}


def validate_troca_senha(data: dict):
    errors = {}
    atual = data.get("senha_atual") or ""
    nova = data.get("senha_nova") or ""
    if not atual:
        errors["senha_atual"] = "Informe a senha atual."
    if not isinstance(nova, str) or len(nova) < 8:
        errors["senha_nova"] = "A nova senha deve ter pelo menos 8 caracteres."
    if errors:
        raise ValidationError(errors)
    return {"senha_atual": atual, "senha_nova": nova}


def _to_float(value, field, errors, default=0.0, min_value=0.0, max_value=10_000_000):
    if value in (None, ""):
        return default
    try:
        if isinstance(value, str):
            value = value.replace(".", "").replace(",", ".") if "," in value else value
        v = float(value)
    except (TypeError, ValueError):
        errors[field] = "Valor numérico inválido."
        return default
    if v < min_value or v > max_value:
        errors[field] = "Valor fora do intervalo permitido."
        return default
    return round(v, 2)


def validate_onboarding(data: dict):
    errors = {}
    nome = _s(data.get("nome"))
    if not nome or not NOME_RE.match(nome):
        errors["nome"] = "Informe um nome válido."

    salario = _to_float(data.get("salario"), "salario", errors, default=0.0)
    va = _to_float(data.get("va"), "va", errors, default=0.0)
    contas = _to_float(data.get("contas"), "contas", errors, default=0.0)

    dividas = _s(data.get("dividas")) or "nao"
    if dividas not in ("sim", "nao"):
        errors["dividas"] = "Valor inválido para dívidas."

    objetivo = _s(data.get("objetivo"))
    if not objetivo:
        errors["objetivo"] = "Selecione um objetivo."

    try:
        prazo = int(data.get("prazo") or 6)
    except (TypeError, ValueError):
        prazo = 6
    prazo = max(1, min(prazo, 60))

    objetivo_texto_livre = _s(data.get("objetivo_texto_livre"))[:1000]

    if errors:
        raise ValidationError(errors)

    return {
        "nome": nome,
        "salario": salario,
        "va": va,
        "contas": contas,
        "dividas": dividas,
        "objetivo": objetivo,
        "prazo": prazo,
        "objetivo_texto_livre": objetivo_texto_livre,
    }


def validate_gasto(data: dict):
    errors = {}
    texto = _s(data.get("texto"))
    if not texto:
        errors["texto"] = "Descreva o gasto."
    elif len(texto) > 300:
        errors["texto"] = "Texto muito longo (máx. 300 caracteres)."
    if errors:
        raise ValidationError(errors)
    return {"texto": texto}


def validate_gasto_impulso(data: dict):
    errors = {}
    descricao = _s(data.get("descricao"))
    if not descricao:
        errors["descricao"] = "Descreva a compra."
    elif len(descricao) > 300:
        errors["descricao"] = "Texto muito longo."
    valor = _to_float(data.get("valor"), "valor", errors, default=None, min_value=0.01)
    if valor is None and "valor" not in errors:
        errors["valor"] = "Informe o valor gasto."
    gatilho = _s(data.get("gatilho"))[:300]
    if errors:
        raise ValidationError(errors)
    return {"descricao": descricao, "valor": valor, "gatilho": gatilho}


def validate_chat_mensagem(data: dict):
    errors = {}
    mensagem = _s(data.get("mensagem"))
    if not mensagem:
        errors["mensagem"] = "Digite uma mensagem."
    elif len(mensagem) > 800:
        errors["mensagem"] = "Mensagem muito longa (máx. 800 caracteres)."
    if errors:
        raise ValidationError(errors)
    return {"mensagem": mensagem}


def validate_divida(data: dict):
    errors = {}
    nome = _s(data.get("nome"))
    if not nome:
        errors["nome"] = "Dê um nome pra essa dívida (ex.: Cartão de crédito)."
    elif len(nome) > 100:
        errors["nome"] = "Nome muito longo."
    valor = _to_float(data.get("valor"), "valor", errors, default=None, min_value=0.01)
    if valor is None and "valor" not in errors:
        errors["valor"] = "Informe quanto ainda falta pagar dessa dívida."
    if errors:
        raise ValidationError(errors)
    return {"nome": nome, "valor": valor}


def validate_novo_codigo(data: dict):
    errors = {}
    try:
        max_usos = int(data.get("max_usos") or 1)
    except (TypeError, ValueError):
        max_usos = 1
    max_usos = max(1, min(max_usos, 1000))
    observacao = _s(data.get("observacao"))[:200]
    codigo = _s(data.get("codigo")).upper()
    if codigo and not CODIGO_RE.match(codigo):
        errors["codigo"] = "Código inválido (use apenas letras, números e hífen)."
    if errors:
        raise ValidationError(errors)
    return {"codigo": codigo, "max_usos": max_usos, "observacao": observacao}
