"""Utilidades de segurança: hash de senha, sanitização e sessão."""
import bcrypt
import bleach
import secrets


def hash_senha(senha: str) -> str:
    """Gera hash bcrypt da senha (nunca armazenar texto puro)."""
    return bcrypt.hashpw(senha.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")


def checar_senha(senha: str, senha_hash: str) -> bool:
    if not senha_hash:
        return False
    try:
        return bcrypt.checkpw(senha.encode("utf-8"), senha_hash.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def gerar_session_token() -> str:
    """Token aleatório usado para permitir 'lembrar sessão' e invalidação remota."""
    return secrets.token_hex(32)


def gerar_codigo_acesso() -> str:
    return secrets.token_hex(4).upper()


def sanitize_text(value: str) -> str:
    """Remove qualquer HTML/script de um texto vindo do usuário (proteção XSS).

    Usado antes de persistir texto livre no banco e novamente ao montar
    prompts para a IA, para nunca ecoar HTML não confiável de volta ao front-end.
    """
    if not value:
        return ""
    cleaned = bleach.clean(value, tags=[], attributes={}, strip=True)
    return cleaned.strip()
