"""Decorators de proteção de rotas."""
from functools import wraps
from flask import session, redirect, url_for, jsonify, request, g
from services.auth_service import get_usuario_by_id


def _wants_json():
    return request.path.startswith("/api/") or request.accept_mimetypes.best == "application/json"


def login_required(view):
    """Protege páginas/rotas: exige sessão válida, senão redireciona/retorna 401."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        usuario_id = session.get("usuario_id")
        session_token = session.get("session_token")
        usuario = get_usuario_by_id(usuario_id) if usuario_id else None

        # Sessão só é válida se o token bater com o armazenado no banco
        # (permite logout remoto / invalidação pelo admin).
        if not usuario or usuario.get("session_token") != session_token:
            session.clear()
            if _wants_json():
                return jsonify({"ok": False, "erro": "Sessão expirada. Faça login novamente."}), 401
            return redirect(url_for("pages.login_page"))

        if usuario.get("status") != "ativo":
            session.clear()
            if _wants_json():
                return jsonify({"ok": False, "erro": "Conta suspensa."}), 403
            return redirect(url_for("pages.login_page"))

        g.usuario = usuario
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        usuario = getattr(g, "usuario", None)
        if not usuario or not usuario.get("is_admin"):
            if _wants_json():
                return jsonify({"ok": False, "erro": "Acesso restrito ao administrador."}), 403
            return redirect(url_for("pages.login_page"))
        return view(*args, **kwargs)
    return wrapped
