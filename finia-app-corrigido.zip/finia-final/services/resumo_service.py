"""Agrega dados de várias tabelas para montar o dashboard e a tela de evolução."""
from datetime import date
from database.supabase_client import get_client, safe_call
from services import finance_service, gastos_service, impulso_service, plano_service, dividas_service
from api import ai_service


def _upsert_resumo_mensal(usuario_id, ano, mes, campos):
    def _run():
        return (
            get_client()
            .table("resumos_mensais")
            .upsert({"usuario_id": usuario_id, "ano": ano, "mes": mes, **campos},
                    on_conflict="usuario_id,ano,mes")
            .execute()
        )
    safe_call(_run, log_label="upsert_resumo_mensal")


def montar_dashboard(usuario_id: str, nome: str) -> dict:
    hoje = date.today()
    plano = plano_service.obter_plano_atual(usuario_id)
    objetivo = plano_service.obter_objetivo_ativo(usuario_id)
    perfil = plano_service.obter_perfil(usuario_id)

    gastos_mes = gastos_service.total_gastos_mes(usuario_id, hoje.year, hoje.month)
    resumo_impulso = impulso_service.resumo_impulso(usuario_id)
    dividas_total = dividas_service.total_dividas_ativas(usuario_id)
    lista_dividas = dividas_service.listar_dividas(usuario_id, apenas_ativas=True)

    entradas = plano["entradas"] if plano else 0.0
    # Contas fixas e vale-alimentação vêm direto do perfil salvo no
    # onboarding — muito mais confiável do que tentar reconstruir por
    # subtração (o jeito antigo quebrava sempre que qualquer outro valor
    # mudava de fórmula).
    contas_fixas_plano = perfil["contas_fixas"] if perfil else 0.0
    orcamento_alimentacao = perfil["vale_alimentacao"] if perfil else 0.0
    salario = perfil["salario"] if perfil else entradas

    # O vale-alimentação é dinheiro carimbado pra comida, não conta como
    # "sobra livre" pra qualquer coisa. Aqui comparamos com o que já foi
    # gasto em Alimentação neste mês, pra mostrar quanto ainda resta do vale.
    categorias_mes = gastos_service.totais_por_categoria(usuario_id, hoje.year, hoje.month)
    gasto_alimentacao_mes = categorias_mes.get("Alimentação", 0.0)
    alimentacao_restante = round(max(orcamento_alimentacao - gasto_alimentacao_mes, 0), 2)

    # "Saldo" e "economizado" são calculados só em cima do salário (dinheiro
    # livre) — o vale-alimentação já foi tratado à parte acima.
    saldo = round(max(salario - contas_fixas_plano - gastos_mes - resumo_impulso["total_mes_atual"], 0), 2)
    meta_mensal = plano["meta_mensal"] if plano else 0.0
    # "Economizado" reflete o saldo real que sobrou depois dos gastos
    # registrados no mês (nunca um valor assumido/inventado). Ainda limitamos
    # à meta mensal para a narrativa fazer sentido ("economizou X rumo à
    # meta de Y"), mas o número em si vem do comportamento real do usuário.
    economizado = min(saldo, meta_mensal) if meta_mensal else saldo

    valor_meta = objetivo["valor_meta"] if objetivo else 0.0
    valor_atual = objetivo["valor_atual"] if objetivo else 0.0
    meta_percent = round(min((valor_atual / valor_meta) * 100, 100), 1) if valor_meta else 0.0

    taxa_economia = (economizado / salario) if salario else 0.0
    gastos_impulso_percent = (resumo_impulso["total_mes_atual"] / salario) if salario else 0.0
    pontuacao = finance_service.calcular_pontuacao(
        meses_ativo=3,
        taxa_economia=taxa_economia,
        gastos_impulsivos_percent=gastos_impulso_percent,
        meta_progresso_percent=meta_percent / 100,
    )

    # "Para onde vai o dinheiro": mostra o destino de CADA parte do salário,
    # incluindo o que sobra depois de contas + reserva + meta + lazer — pra
    # nunca deixar a pergunta "e o resto, o que eu faço?" sem resposta.
    reserva_sugerida = plano["reserva_sugerida"] if plano else 0.0
    disponivel_lazer = plano["disponivel_lazer"] if plano else 0.0
    soma_alocada = round(contas_fixas_plano + reserva_sugerida + meta_mensal + disponivel_lazer, 2)
    nao_alocado = round(max(salario - soma_alocada, 0), 2)

    mensagem_ia = ai_service.gerar_dica_dashboard({
        "nome": nome,
        "economizado": economizado,
        "objetivo": objetivo["titulo"] if objetivo else "seu objetivo",
        "meta_percent": meta_percent,
        "dividas_total": dividas_total,
        "alimentacao_restante": alimentacao_restante,
    })

    _upsert_resumo_mensal(usuario_id, hoje.year, hoje.month, {
        "total_entradas": entradas,
        "total_gastos": gastos_mes,
        "total_gastos_impulsivos": resumo_impulso["total_mes_atual"],
        "total_economizado": economizado,
        "pontuacao_financeira": pontuacao,
    })

    return {
        "saldo": saldo,
        "economizado": economizado,
        "pontuacao": pontuacao,
        "objetivo": {
            "titulo": objetivo["titulo"] if objetivo else None,
            "prazo_meses": objetivo["prazo_meses"] if objetivo else None,
            "valor_meta": valor_meta,
            "valor_atual": valor_atual,
            "percent": meta_percent,
        },
        "resumo_mes": {
            "entradas": entradas,
            "salario": salario,
            "vale_alimentacao": orcamento_alimentacao,
            "gastos": gastos_mes,
            "contas_fixas": contas_fixas_plano,
            "disponivel_lazer": disponivel_lazer,
        },
        "alimentacao": {
            "orcamento": orcamento_alimentacao,
            "gasto_mes": gasto_alimentacao_mes,
            "restante": alimentacao_restante,
        },
        "alocacao": {
            "salario": salario,
            "contas_fixas": contas_fixas_plano,
            "reserva_sugerida": reserva_sugerida,
            "meta_mensal": meta_mensal,
            "disponivel_lazer": disponivel_lazer,
            "nao_alocado": nao_alocado,
        },
        "dividas": {
            "total_ativo": dividas_total,
            "itens": lista_dividas,
        },
        "mensagem_ia": mensagem_ia,
        "onboarding_pendente": plano is None,
    }


def montar_evolucao(usuario_id: str) -> dict:
    hoje = date.today()
    meses_labels = []
    economia_mensal = []
    gasto_mensal = []

    # Últimos 6 meses (incluindo o atual)
    ano, mes = hoje.year, hoje.month
    pares = []
    for _ in range(6):
        pares.append((ano, mes))
        mes -= 1
        if mes == 0:
            mes = 12
            ano -= 1
    pares.reverse()

    def _run():
        res = (
            get_client()
            .table("resumos_mensais")
            .select("*")
            .eq("usuario_id", usuario_id)
            .execute()
        )
        return {(r["ano"], r["mes"]): r for r in (res.data or [])}
    resumos = safe_call(_run, default={}, log_label="montar_evolucao")

    nomes_meses = ["", "Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
    for (a, m) in pares:
        meses_labels.append(nomes_meses[m])
        r = resumos.get((a, m))
        economia_mensal.append(r["total_economizado"] if r else 0)
        gasto_mensal.append(r["total_gastos"] if r else 0)

    categorias = gastos_service.totais_por_categoria(usuario_id, hoje.year, hoje.month)
    categorias_lista = [{"label": k, "valor": v} for k, v in sorted(categorias.items(), key=lambda x: -x[1])]

    # Resumo do topo da tela: total economizado no período, variação real vs
    # mês anterior (calculada, não fixa) e a pontuação atual — antes esses
    # 3 números eram fixos no HTML e nunca mudavam.
    total_economizado_periodo = round(sum(economia_mensal), 2)
    mes_atual_valor = economia_mensal[-1] if economia_mensal else 0
    mes_anterior_valor = economia_mensal[-2] if len(economia_mensal) >= 2 else 0
    if mes_anterior_valor:
        variacao_percent = round(((mes_atual_valor - mes_anterior_valor) / mes_anterior_valor) * 100, 1)
    else:
        variacao_percent = 0.0

    plano = plano_service.obter_plano_atual(usuario_id)
    objetivo = plano_service.obter_objetivo_ativo(usuario_id)
    resumo_impulso = impulso_service.resumo_impulso(usuario_id)
    entradas = plano["entradas"] if plano else 0.0
    valor_meta = objetivo["valor_meta"] if objetivo else 0.0
    valor_atual = objetivo["valor_atual"] if objetivo else 0.0
    meta_percent = round(min((valor_atual / valor_meta) * 100, 100), 1) if valor_meta else 0.0
    taxa_economia = (mes_atual_valor / entradas) if entradas else 0.0
    gastos_impulso_percent = (resumo_impulso["total_mes_atual"] / entradas) if entradas else 0.0
    pontuacao = finance_service.calcular_pontuacao(
        meses_ativo=3,
        taxa_economia=taxa_economia,
        gastos_impulsivos_percent=gastos_impulso_percent,
        meta_progresso_percent=meta_percent / 100,
    )

    return {
        "meses": meses_labels,
        "economia_mensal": economia_mensal,
        "gasto_mensal": gasto_mensal,
        "categorias": categorias_lista,
        "total_economizado_periodo": total_economizado_periodo,
        "variacao_percent": variacao_percent,
        "pontuacao": pontuacao,
    }
