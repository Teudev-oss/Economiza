"""Regras de negócio de gastos comuns (não impulsivos)."""
from datetime import date
from database.supabase_client import get_client, safe_call
from services.finance_service import detectar_categoria, detectar_valor
from utils.security import sanitize_text


def registrar_gasto(usuario_id: str, texto: str):
    texto_limpo = sanitize_text(texto)
    valor = detectar_valor(texto_limpo)
    categoria = detectar_categoria(texto_limpo)

    if valor is None:
        return None, texto_limpo, categoria

    def _run():
        return (
            get_client()
            .table("gastos")
            .insert({
                "usuario_id": usuario_id,
                "descricao": texto_limpo[:300],
                "categoria": categoria,
                "valor": valor,
                "data_gasto": date.today().isoformat(),
                "origem": "manual",
            })
            .execute()
        )
    res = safe_call(_run, log_label="registrar_gasto")
    gasto = res.data[0] if res and res.data else None
    return gasto, texto_limpo, categoria


def listar_gastos(usuario_id: str, limite: int = 50):
    def _run():
        res = (
            get_client()
            .table("gastos")
            .select("*")
            .eq("usuario_id", usuario_id)
            .order("data_gasto", desc=True)
            .limit(limite)
            .execute()
        )
        return res.data or []
    return safe_call(_run, default=[], log_label="listar_gastos")


def total_gastos_mes(usuario_id: str, ano: int, mes: int) -> float:
    gastos = listar_gastos(usuario_id, limite=1000)
    total = 0.0
    for g in gastos:
        try:
            d = date.fromisoformat(g["data_gasto"])
        except (KeyError, ValueError, TypeError):
            continue
        if d.year == ano and d.month == mes:
            total += float(g.get("valor") or 0)
    return round(total, 2)


def totais_por_categoria(usuario_id: str, ano: int, mes: int) -> dict:
    gastos = listar_gastos(usuario_id, limite=1000)
    totais = {}
    for g in gastos:
        try:
            d = date.fromisoformat(g["data_gasto"])
        except (KeyError, ValueError, TypeError):
            continue
        if d.year == ano and d.month == mes:
            cat = g.get("categoria", "Outros")
            totais[cat] = round(totais.get(cat, 0) + float(g.get("valor") or 0), 2)
    return totais
