"""Camada de acesso a dados do histórico de chat com a IA."""
from database.supabase_client import get_client, safe_call


def salvar_mensagem(usuario_id, autor, mensagem):
    def _run():
        return (
            get_client()
            .table("historico_chat_ia")
            .insert({"usuario_id": usuario_id, "autor": autor, "mensagem": mensagem})
            .execute()
        )
    safe_call(_run, log_label="salvar_mensagem_chat")


def listar_historico(usuario_id, limite=30):
    def _run():
        res = (
            get_client()
            .table("historico_chat_ia")
            .select("*")
            .eq("usuario_id", usuario_id)
            .order("created_at", desc=True)
            .limit(limite)
            .execute()
        )
        return list(reversed(res.data or []))
    return safe_call(_run, default=[], log_label="listar_historico_chat")
