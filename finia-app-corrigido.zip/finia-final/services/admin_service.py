"""Regras de negócio do painel administrativo."""
from database.supabase_client import get_client, safe_call
from utils.security import gerar_codigo_acesso


def listar_usuarios(busca: str = ""):
    def _run():
        query = get_client().table("usuarios").select(
            "id, nome, status, is_admin, onboarding_done, ultimo_acesso, created_at"
        ).order("created_at", desc=True)
        if busca:
            query = query.ilike("nome", f"%{busca}%")
        res = query.limit(200).execute()
        return res.data or []
    return safe_call(_run, default=[], log_label="listar_usuarios")


def contar_usuarios_online(minutos: int = 15):
    # "Online" = teve acesso recente. Cálculo simples feito em Python
    # (Supabase-py não expõe filtros de intervalo de forma direta aqui).
    from datetime import datetime, timedelta, timezone
    limite = datetime.now(timezone.utc) - timedelta(minutes=minutos)
    usuarios = listar_usuarios()
    online = 0
    for u in usuarios:
        ultimo = u.get("ultimo_acesso")
        if not ultimo:
            continue
        try:
            dt = datetime.fromisoformat(ultimo.replace("Z", "+00:00"))
        except ValueError:
            continue
        if dt >= limite:
            online += 1
    return online, len(usuarios)


def listar_logs(limite: int = 50):
    def _run():
        res = (
            get_client()
            .table("logs_acesso")
            .select("*, usuarios(nome)")
            .order("created_at", desc=True)
            .limit(limite)
            .execute()
        )
        return res.data or []
    return safe_call(_run, default=[], log_label="listar_logs")


def listar_codigos():
    def _run():
        res = get_client().table("codigos_acesso").select("*").order("created_at", desc=True).execute()
        return res.data or []
    return safe_call(_run, default=[], log_label="listar_codigos")


def criar_codigo(max_usos: int = 1, observacao: str = "", codigo: str = "", criado_por: str = ""):
    codigo_final = codigo or gerar_codigo_acesso()

    def _run():
        return (
            get_client()
            .table("codigos_acesso")
            .insert({
                "codigo": codigo_final,
                "max_usos": max_usos,
                "observacao": observacao,
                "criado_por": criado_por,
            })
            .execute()
        )
    res = safe_call(_run, log_label="criar_codigo")
    if not res or not res.data:
        raise ValueError("Não foi possível criar o código (talvez já exista).")
    return res.data[0]


def revogar_codigo(codigo_id: str):
    def _run():
        return get_client().table("codigos_acesso").update({"ativo": False}).eq("id", codigo_id).execute()
    safe_call(_run, log_label="revogar_codigo")


def contagem_gastos_e_objetivos(usuario_id: str):
    def _run_gastos():
        res = get_client().table("gastos").select("id", count="exact").eq("usuario_id", usuario_id).execute()
        return res.count or 0

    def _run_objetivos():
        res = get_client().table("objetivos").select("id", count="exact").eq("usuario_id", usuario_id).execute()
        return res.count or 0

    return {
        "gastos": safe_call(_run_gastos, default=0, log_label="contagem_gastos"),
        "objetivos": safe_call(_run_objetivos, default=0, log_label="contagem_objetivos"),
    }
