"""Gerencia as dívidas do usuário: quanto deve, quais estão ativas, quais
já foram quitadas. Antes o onboarding só perguntava "tem dívidas? sim/não"
e esse dado nunca era usado em lugar nenhum — agora dá pra registrar cada
dívida com nome e valor, ver o total ativo e quitar quando pagar.
"""
from database.supabase_client import get_client, safe_call


def listar_dividas(usuario_id: str, apenas_ativas: bool = False):
    def _run():
        query = (
            get_client()
            .table("dividas")
            .select("*")
            .eq("usuario_id", usuario_id)
        )
        if apenas_ativas:
            query = query.eq("ativa", True)
        res = query.order("created_at", desc=True).execute()
        return res.data or []
    return safe_call(_run, default=[], log_label="listar_dividas")


def total_dividas_ativas(usuario_id: str) -> float:
    itens = listar_dividas(usuario_id, apenas_ativas=True)
    return round(sum(float(i["valor"]) for i in itens), 2)


def criar_divida(usuario_id: str, nome: str, valor: float):
    def _run():
        return (
            get_client()
            .table("dividas")
            .insert({
                "usuario_id": usuario_id,
                "nome": nome,
                "valor": round(max(valor, 0), 2),
                "ativa": True,
            })
            .execute()
        )
    res = safe_call(_run, log_label="criar_divida")
    return res.data[0] if res and res.data else None


def quitar_divida(usuario_id: str, divida_id: str):
    def _run():
        return (
            get_client()
            .table("dividas")
            .update({"ativa": False})
            .eq("id", divida_id)
            .eq("usuario_id", usuario_id)
            .execute()
        )
    res = safe_call(_run, log_label="quitar_divida")
    return bool(res and res.data)


def excluir_divida(usuario_id: str, divida_id: str):
    def _run():
        return (
            get_client()
            .table("dividas")
            .delete()
            .eq("id", divida_id)
            .eq("usuario_id", usuario_id)
            .execute()
        )
    res = safe_call(_run, log_label="excluir_divida")
    return bool(res and res.data)
