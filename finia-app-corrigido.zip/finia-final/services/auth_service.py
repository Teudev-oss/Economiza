"""Regras de negócio de autenticação e códigos de acesso."""
from datetime import datetime, timezone
from database.supabase_client import get_client, safe_call
from utils.security import hash_senha, checar_senha, gerar_session_token


def get_usuario_by_id(usuario_id: str):
    if not usuario_id:
        return None
    def _run():
        res = get_client().table("usuarios").select("*").eq("id", usuario_id).limit(1).execute()
        return res.data[0] if res.data else None
    return safe_call(_run, log_label="get_usuario_by_id")


def get_usuario_by_nome(nome: str):
    nome_norm = nome.strip().lower()
    def _run():
        res = get_client().table("usuarios").select("*").eq("nome_normalizado", nome_norm).limit(1).execute()
        return res.data[0] if res.data else None
    return safe_call(_run, log_label="get_usuario_by_nome")


def validar_codigo_acesso(codigo: str):
    """Retorna o registro do código se ele estiver válido e com usos disponíveis."""
    def _run():
        res = (
            get_client()
            .table("codigos_acesso")
            .select("*")
            .eq("codigo", codigo)
            .eq("ativo", True)
            .limit(1)
            .execute()
        )
        return res.data[0] if res.data else None
    row = safe_call(_run, log_label="validar_codigo_acesso")
    if not row:
        return None
    if row["usos"] >= row["max_usos"]:
        return None
    return row


def _consumir_codigo(codigo_id: str, usos_atual: int):
    def _run():
        return (
            get_client()
            .table("codigos_acesso")
            .update({"usos": usos_atual + 1})
            .eq("id", codigo_id)
            .execute()
        )
    safe_call(_run, log_label="consumir_codigo")


def criar_usuario(nome: str, senha: str, codigo_acesso: str, is_admin: bool = False):
    """Cria usuário novo. Levanta ValueError com mensagem amigável em caso de erro de regra."""
    if get_usuario_by_nome(nome):
        raise ValueError("Já existe uma conta com esse nome. Tente outro ou faça login.")

    codigo_row = validar_codigo_acesso(codigo_acesso)
    if not codigo_row:
        raise ValueError("Código de acesso inválido, expirado ou já utilizado.")

    senha_hash = hash_senha(senha)
    session_token = gerar_session_token()

    def _run():
        return (
            get_client()
            .table("usuarios")
            .insert({
                "nome": nome,
                "senha_hash": senha_hash,
                "codigo_acesso_id": codigo_row["id"],
                "is_admin": is_admin,
                "onboarding_done": False,
                "session_token": session_token,
                "ultimo_acesso": datetime.now(timezone.utc).isoformat(),
            })
            .execute()
        )
    res = safe_call(_run, log_label="criar_usuario")
    if not res or not res.data:
        raise ValueError("Não foi possível criar a conta. Tente novamente em instantes.")

    _consumir_codigo(codigo_row["id"], codigo_row["usos"])
    return res.data[0]


def autenticar(nome: str, senha: str):
    """Retorna (usuario, novo_session_token) se credenciais forem válidas, senão None."""
    usuario = get_usuario_by_nome(nome)
    if not usuario or not checar_senha(senha, usuario.get("senha_hash", "")):
        return None, None

    novo_token = gerar_session_token()

    def _run():
        return (
            get_client()
            .table("usuarios")
            .update({
                "session_token": novo_token,
                "ultimo_acesso": datetime.now(timezone.utc).isoformat(),
            })
            .eq("id", usuario["id"])
            .execute()
        )
    safe_call(_run, log_label="autenticar_update")
    usuario["session_token"] = novo_token
    return usuario, novo_token


def invalidar_sessao(usuario_id: str):
    def _run():
        return (
            get_client()
            .table("usuarios")
            .update({"session_token": None})
            .eq("id", usuario_id)
            .execute()
        )
    safe_call(_run, log_label="invalidar_sessao")


def marcar_onboarding_concluido(usuario_id: str):
    def _run():
        return (
            get_client()
            .table("usuarios")
            .update({"onboarding_done": True})
            .eq("id", usuario_id)
            .execute()
        )
    safe_call(_run, log_label="marcar_onboarding")


def trocar_senha(usuario_id: str, senha_atual: str, senha_nova: str):
    usuario = get_usuario_by_id(usuario_id)
    if not usuario or not checar_senha(senha_atual, usuario.get("senha_hash", "")):
        raise ValueError("Senha atual incorreta.")
    novo_hash = hash_senha(senha_nova)

    def _run():
        return (
            get_client()
            .table("usuarios")
            .update({"senha_hash": novo_hash})
            .eq("id", usuario_id)
            .execute()
        )
    safe_call(_run, log_label="trocar_senha")


def registrar_log_acesso(usuario_id, evento: str, ip: str = None, user_agent: str = None):
    def _run():
        return (
            get_client()
            .table("logs_acesso")
            .insert({
                "usuario_id": usuario_id,
                "evento": evento,
                "ip": ip,
                "user_agent": (user_agent or "")[:300],
            })
            .execute()
        )
    safe_call(_run, log_label="registrar_log_acesso")
