"""Orquestra a criação/atualização do plano financeiro.

Mantém a separação clara do projeto: os números vêm sempre do
`finance_service` (Python puro); a IA (`ai_service`) só entra para narrar o
resultado em linguagem natural.
"""
from database.supabase_client import get_client, safe_call
from services import finance_service
from api import ai_service

# Multiplicador usado para sugerir um valor de meta quando o usuário não informa
# um valor específico: a meta padrão vira N meses da renda total do usuário,
# então ela sempre escala com o que a pessoa realmente ganha (em vez de um
# valor fixo igual pra todo mundo, que não fazia sentido pra quem ganha pouco
# nem pra quem ganha muito).
MESES_RENDA_META_PADRAO = 6


def _valor_meta_padrao(salario: float, va: float) -> float:
    entradas = max(salario or 0, 0) + max(va or 0, 0)
    return round(entradas * MESES_RENDA_META_PADRAO, 2)


def _salvar_perfil(usuario_id, dados):
    def _run():
        return (
            get_client()
            .table("perfis_financeiros")
            .insert({
                "usuario_id": usuario_id,
                "salario": dados["salario"],
                "vale_alimentacao": dados["va"],
                "contas_fixas": dados["contas"],
                "possui_dividas": dados["dividas"],
                "objetivo_texto_livre": dados["objetivo_texto_livre"],
            })
            .execute()
        )
    res = safe_call(_run, log_label="salvar_perfil")
    return res.data[0] if res and res.data else None


def _criar_objetivo(usuario_id, dados):
    valor_meta = _valor_meta_padrao(dados["salario"], dados["va"])

    def _run():
        return (
            get_client()
            .table("objetivos")
            .insert({
                "usuario_id": usuario_id,
                "titulo": dados["objetivo"],
                "prazo_meses": dados["prazo"],
                "valor_meta": valor_meta,
                "valor_atual": 0,
            })
            .execute()
        )
    res = safe_call(_run, log_label="criar_objetivo")
    return res.data[0] if res and res.data else None


def _salvar_plano(usuario_id, objetivo_id, calculo, mensagem_ia):
    checklist_padrao = [
        {"id": "c1", "texto": "Separar a reserva sugerida assim que o salário cair", "done": False},
        {"id": "c2", "texto": "Revisar assinaturas e cortar o que não usa", "done": False},
        {"id": "c3", "texto": "Registrar todos os gastos da semana no app", "done": False},
        {"id": "c4", "texto": "Guardar a meta mensal de economia", "done": False},
    ]

    def _run():
        return (
            get_client()
            .table("planos_financeiros")
            .insert({
                "usuario_id": usuario_id,
                "objetivo_id": objetivo_id,
                "entradas": calculo["entradas"],
                "saidas_estimadas": calculo["saidas_estimadas"],
                "reserva_sugerida": calculo["reserva_sugerida"],
                "meta_mensal": calculo["meta_mensal"],
                "disponivel_lazer": calculo["disponivel_lazer"],
                "disponivel_economia": calculo["disponivel_economia"],
                "checklist": checklist_padrao,
                "mensagem_ia": mensagem_ia,
                "versao": 1,
            })
            .execute()
        )
    res = safe_call(_run, log_label="salvar_plano")
    return res.data[0] if res and res.data else None


def criar_plano_onboarding(usuario_id: str, dados: dict):
    """Fluxo completo do onboarding: salva perfil, cria objetivo, calcula o
    plano e pede à IA uma mensagem de boas-vindas personalizada."""
    _salvar_perfil(usuario_id, dados)
    objetivo = _criar_objetivo(usuario_id, dados)
    valor_meta = objetivo["valor_meta"] if objetivo else _valor_meta_padrao(dados["salario"], dados["va"])

    calculo = finance_service.calcular_plano(
        salario=dados["salario"],
        vale_alimentacao=dados["va"],
        contas_fixas=dados["contas"],
        valor_meta=valor_meta,
        prazo_meses=dados["prazo"],
    )

    mensagem_ia = ai_service.gerar_plano_inicial(
        perfil={"nome": dados["nome"], "objetivo": dados["objetivo"], "prazo": dados["prazo"]},
        calculo=calculo,
        objetivo_texto_livre=dados["objetivo_texto_livre"],
    )

    plano = _salvar_plano(usuario_id, objetivo["id"] if objetivo else None, calculo, mensagem_ia)
    return {"plano": plano, "objetivo": objetivo, "calculo": calculo, "mensagem_ia": mensagem_ia}


def obter_perfil(usuario_id: str):
    """Retorna o perfil financeiro (salário e vale separados) para telas que
    precisam mostrar a composição da renda, não só o total somado."""
    def _run():
        res = (
            get_client()
            .table("perfis_financeiros")
            .select("*")
            .eq("usuario_id", usuario_id)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        return res.data[0] if res.data else None
    return safe_call(_run, log_label="obter_perfil")


def obter_plano_atual(usuario_id: str):
    def _run():
        res = (
            get_client()
            .table("planos_financeiros")
            .select("*")
            .eq("usuario_id", usuario_id)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        return res.data[0] if res.data else None
    return safe_call(_run, log_label="obter_plano_atual")


def obter_objetivo_ativo(usuario_id: str):
    def _run():
        res = (
            get_client()
            .table("objetivos")
            .select("*")
            .eq("usuario_id", usuario_id)
            .eq("status", "ativo")
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        return res.data[0] if res.data else None
    return safe_call(_run, log_label="obter_objetivo_ativo")


def atualizar_checklist(usuario_id: str, plano_id: str, item_id: str, done: bool):
    plano = obter_plano_atual(usuario_id)
    if not plano or plano["id"] != plano_id:
        return None
    checklist = plano.get("checklist") or []
    for item in checklist:
        if item.get("id") == item_id:
            item["done"] = done

    def _run():
        return (
            get_client()
            .table("planos_financeiros")
            .update({"checklist": checklist})
            .eq("id", plano_id)
            .execute()
        )
    safe_call(_run, log_label="atualizar_checklist")
    return checklist


def atualizar_valor_meta_atual(usuario_id: str, objetivo_id: str, novo_valor_atual: float):
    def _run():
        return (
            get_client()
            .table("objetivos")
            .update({"valor_atual": round(max(novo_valor_atual, 0), 2)})
            .eq("id", objetivo_id)
            .eq("usuario_id", usuario_id)
            .execute()
        )
    safe_call(_run, log_label="atualizar_valor_meta_atual")
