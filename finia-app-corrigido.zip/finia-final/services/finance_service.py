"""Toda a matemática financeira do sistema.

Regra de ouro do projeto: a IA nunca calcula valores. Todo número que o
usuário vê (saldo, meta mensal, reserva, disponível para lazer/economia,
pontuação) é calculado aqui, em Python puro e testável. A IA só recebe os
resultados prontos para explicar/comentar em linguagem natural.
"""

# Percentuais de referência para uma reserva de emergência saudável
RESERVA_MIN_PERCENT = 0.10   # ao menos 10% da entrada líquida vira reserva
META_MENSAL_MAX_PERCENT = 0.30  # não comprometer mais que 30% da renda livre com a meta


def calcular_plano(salario: float, vale_alimentacao: float, contas_fixas: float,
                    valor_meta: float, prazo_meses: int, gastos_variaveis_estimados: float = None):
    """Calcula a distribuição do orçamento de forma sempre coerente.

    Importante: o vale-alimentação NÃO entra no cálculo de reserva, meta
    mensal ou "disponível para lazer" — ele é dinheiro carimbado pra comida,
    não deve ser contado como se fosse dinheiro livre pra qualquer coisa.
    Ele aparece separadamente como "orçamento de alimentação", comparado
    com os gastos reais da categoria Alimentação em outro serviço.

    Nunca deixa nenhum valor negativo: se as contas fixas consomem mais do
    que a renda, o sistema ajusta a reserva/meta para 0 em vez de gerar um
    número impossível (ex.: "disponível para lazer: -R$120").
    """
    salario = max(salario or 0, 0)
    vale_alimentacao = max(vale_alimentacao or 0, 0)
    entradas = salario + vale_alimentacao  # total pra fins de exibição ("Entradas")
    entradas_livres = salario  # só o salário é considerado dinheiro livre/alocável
    contas_fixas = max(contas_fixas, 0)
    prazo_meses = max(int(prazo_meses or 1), 1)
    valor_meta = max(valor_meta or 0, 0)

    saldo_apos_contas = max(entradas_livres - contas_fixas, 0)

    # Se o usuário não informou gastos variáveis, estimamos uma média
    # conservadora (42% da renda livre) só para dar um ponto de partida —
    # esse número é substituído pelos gastos reais assim que existirem.
    if gastos_variaveis_estimados is None:
        gastos_variaveis_estimados = round(saldo_apos_contas * 0.42, 2)
    gastos_variaveis_estimados = min(max(gastos_variaveis_estimados, 0), saldo_apos_contas)

    saldo_livre = max(saldo_apos_contas - gastos_variaveis_estimados, 0)

    reserva_sugerida = round(entradas_livres * RESERVA_MIN_PERCENT, 2)
    reserva_sugerida = min(reserva_sugerida, saldo_livre)

    saldo_pos_reserva = max(saldo_livre - reserva_sugerida, 0)

    # Meta mensal necessária para bater o objetivo no prazo informado
    meta_mensal_necessaria = round(valor_meta / prazo_meses, 2) if valor_meta else 0.0
    # Nunca compromete mais que META_MENSAL_MAX_PERCENT (30%) do saldo livre pós-reserva
    limite_meta_mensal = round(saldo_pos_reserva * META_MENSAL_MAX_PERCENT, 2)
    meta_mensal = min(meta_mensal_necessaria, limite_meta_mensal) if meta_mensal_necessaria else 0.0

    disponivel_economia = meta_mensal
    disponivel_lazer = max(saldo_pos_reserva - disponivel_economia, 0)

    saldo_disponivel = max(entradas_livres - contas_fixas - gastos_variaveis_estimados, 0)

    return {
        "entradas": round(entradas, 2),
        "orcamento_alimentacao": round(vale_alimentacao, 2),
        "contas_fixas": round(contas_fixas, 2),
        "saidas_estimadas": round(gastos_variaveis_estimados, 2),
        "reserva_sugerida": round(reserva_sugerida, 2),
        "meta_mensal": round(meta_mensal, 2),
        "meta_mensal_necessaria_para_prazo": round(meta_mensal_necessaria, 2),
        "prazo_suficiente": meta_mensal_necessaria <= saldo_pos_reserva if valor_meta else True,
        "disponivel_lazer": round(disponivel_lazer, 2),
        "disponivel_economia": round(disponivel_economia, 2),
        "saldo_disponivel": round(saldo_disponivel, 2),
    }


def calcular_pontuacao(*, meses_ativo: int, taxa_economia: float, gastos_impulsivos_percent: float,
                        meta_progresso_percent: float) -> int:
    """Pontuação financeira de 0 a 1000, baseada em hábitos observáveis."""
    score = 500
    score += min(max(taxa_economia, 0), 1) * 300           # até +300 por economizar bem
    score -= min(max(gastos_impulsivos_percent, 0), 1) * 200  # até -200 por gastos por impulso
    score += min(max(meta_progresso_percent, 0), 1) * 150   # até +150 por progresso na meta
    score += min(meses_ativo, 6) * 8                        # pequeno bônus por consistência/uso
    return int(round(min(max(score, 0), 1000)))


# Palavras-chave usadas para inferir categoria automaticamente a partir do texto do gasto.
CATEGORIAS_PALAVRAS = {
    "Alimentação": ["pizza", "mercado", "restaurante", "lanche", "ifood", "comida", "almoço", "jantar", "padaria"],
    "Transporte": ["uber", "gasolina", "combustivel", "combustível", "onibus", "ônibus", "99", "taxi", "metro", "metrô"],
    "Lazer": ["cinema", "show", "jogo", "bar", "balada", "viagem", "passeio"],
    "Assinaturas": ["netflix", "spotify", "assinatura", "streaming"],
    "Saúde": ["farmacia", "farmácia", "remedio", "remédio", "academia", "medico", "médico"],
    "Vestuário": ["roupa", "tenis", "tênis", "sapato", "loja"],
}


def detectar_categoria(texto: str) -> str:
    lower = (texto or "").lower()
    for categoria, palavras in CATEGORIAS_PALAVRAS.items():
        if any(p in lower for p in palavras):
            return categoria
    return "Outros"


def detectar_valor(texto: str):
    """Extrai o valor monetário do texto livre do gasto.

    Antes pegava o primeiro número da frase, o que quebrava em casos como
    "2 pizzas por 45 reais" (pegava o "2" da quantidade, não o "45" do
    preço). Agora prioriza um número junto de um indicador de dinheiro
    ("R$", "reais", "conto(s)") e, só como último recurso, usa o ÚLTIMO
    número solto da frase — porque no português informal o valor costuma
    vir depois da quantidade/descrição, não antes.
    """
    import re
    if not texto:
        return None
    texto_lower = texto.lower()

    match = re.search(r"r\$\s*(\d+(?:[.,]\d+)?)", texto_lower)
    if not match:
        match = re.search(r"(\d+(?:[.,]\d+)?)\s*(?:reais|conto|contos)\b", texto_lower)
    if match:
        valor_str = match.group(1)
    else:
        todos = re.findall(r"\d+(?:[.,]\d+)?", texto_lower)
        if not todos:
            return None
        valor_str = todos[-1]

    try:
        return round(float(valor_str.replace(",", ".")), 2)
    except ValueError:
        return None
