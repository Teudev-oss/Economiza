"""Regras de negócio da aba 'Gastos por Impulso'."""
from datetime import date
from database.supabase_client import get_client, safe_call
from utils.security import sanitize_text


def registrar_gasto_impulso(usuario_id: str, descricao: str, valor: float, gatilho: str = ""):
    def _run():
        return (
            get_client()
            .table("gastos_impulsivos")
            .insert({
                "usuario_id": usuario_id,
                "descricao": sanitize_text(descricao)[:300],
                "valor": round(valor, 2),
                "gatilho": sanitize_text(gatilho)[:300],
                "data_gasto": date.today().isoformat(),
            })
            .execute()
        )
    res = safe_call(_run, log_label="registrar_gasto_impulso")
    return res.data[0] if res and res.data else None


def listar_gastos_impulso(usuario_id: str, limite: int = 100):
    def _run():
        res = (
            get_client()
            .table("gastos_impulsivos")
            .select("*")
            .eq("usuario_id", usuario_id)
            .order("data_gasto", desc=True)
            .limit(limite)
            .execute()
        )
        return res.data or []
    return safe_call(_run, default=[], log_label="listar_gastos_impulso")


def resumo_impulso(usuario_id: str):
    """Total do mês atual, média dos meses anteriores e evolução mensal (últimos 6 meses)."""
    itens = listar_gastos_impulso(usuario_id, limite=500)
    hoje = date.today()

    por_mes = {}
    for item in itens:
        try:
            d = date.fromisoformat(item["data_gasto"])
        except (KeyError, ValueError, TypeError):
            continue
        chave = (d.year, d.month)
        por_mes[chave] = round(por_mes.get(chave, 0) + float(item.get("valor") or 0), 2)

    total_mes_atual = por_mes.get((hoje.year, hoje.month), 0.0)

    meses_anteriores = [v for k, v in por_mes.items() if k != (hoje.year, hoje.month)]
    media_anterior = round(sum(meses_anteriores) / len(meses_anteriores), 2) if meses_anteriores else 0.0

    # Série para o gráfico de evolução (ordenada, últimos 6 meses com dado)
    serie_ordenada = sorted(por_mes.items())[-6:]
    serie = [{"ano": k[0], "mes": k[1], "total": v} for k, v in serie_ordenada]

    return {
        "total_mes_atual": total_mes_atual,
        "media_meses_anteriores": media_anterior,
        "itens_recentes": itens[:10],
        "serie_mensal": serie,
    }
