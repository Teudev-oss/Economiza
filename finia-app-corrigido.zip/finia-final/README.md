# FinIA — Back-end completo (Flask + Supabase + Groq/DeepSeek)

Assistente financeiro pessoal com IA. Este repositório contém o front-end
original (preservado visualmente) totalmente integrado a um back-end real em
Flask, com autenticação própria (nome + senha + código de acesso), Supabase
como banco de dados e a Groq (modelo DeepSeek) para a camada de IA.

## Arquitetura

```
app.py                 # Application factory do Flask
config.py              # Configuração via variáveis de ambiente
extensions.py          # Instâncias únicas de CSRF e rate limiter
wsgi.py                # Entrypoint para gunicorn / Render

routes/                # Blueprints HTTP (uma responsabilidade por arquivo)
services/              # Regras de negócio + acesso ao Supabase
database/              # Client do Supabase + schema.sql
models/                # Validação de entrada (schemas.py)
api/ai_service.py      # ÚNICO arquivo com a integração Groq/DeepSeek
utils/                 # Segurança (hash, sanitização), decorators de auth

templates/              # HTML original (Jinja), praticamente inalterado
static/                 # CSS, JS, ícones e manifest do PWA (inalterados no visual)
```

### Por que a IA nunca calcula dinheiro

Toda a matemática financeira (saldo, reserva, meta mensal, disponível para
lazer/economia, pontuação) é calculada em `services/finance_service.py`, em
Python puro e determinístico. A IA (`api/ai_service.py`) recebe esses números
já prontos e apenas os explica em linguagem natural — ela nunca é solicitada
a "fazer a conta". Isso evita qualquer alucinação numérica.

## Autenticação

- Cadastro pede **nome, senha e código de acesso** (sem e-mail).
- Códigos de acesso são criados e revogados pelo administrador (`/adm.html`).
- Senhas são armazenadas com **bcrypt** (nunca em texto puro).
- Sessão via cookie assinado (`Flask session`) + token de sessão guardado no
  banco, o que permite **logout remoto** (o admin pode suspender uma conta e
  a sessão é invalidada no próximo request) e recuperação de sessão ao
  recarregar a página.
- Como não há e-mail no sistema, "esqueci minha senha" é resolvido pedindo um
  novo código de acesso ao administrador.

## Segurança implementada

- CSRF (Flask-WTF) em todas as rotas que alteram dados.
- Cookies `HttpOnly`, `SameSite=Lax` e `Secure` (configurável via `.env`).
- Rate limiting no login/cadastro (Flask-Limiter).
- Sanitização de texto livre do usuário (biblioteca `bleach`) antes de
  persistir no banco — proteção contra XSS.
- Toda consulta ao banco passa pelo client oficial do Supabase (sem SQL cru),
  o que já elimina a superfície de SQL Injection.
- Cabeçalhos de segurança (`X-Frame-Options`, CSP, `X-Content-Type-Options`).
- Tratamento de erros centralizado (`app.py`) — nunca expõe stack trace ao
  usuário final.

## Configurando o Supabase

1. Crie um projeto em [supabase.com](https://supabase.com).
2. Abra o **SQL Editor** e execute todo o conteúdo de `database/schema.sql`.
3. Cadastre pelo menos um código de acesso para conseguir criar a primeira
   conta:
   ```sql
   insert into codigos_acesso (codigo, max_usos) values ('BEMVINDO2026', 5);
   ```
   (Alternativa: defina `BOOTSTRAP_ACCESS_CODE` no `.env` — o sistema cria
   esse código automaticamente na primeira inicialização.)
4. Depois de criar sua conta pelo app, promova-a a administrador:
   ```sql
   update usuarios set is_admin = true where nome_normalizado = 'seu nome aqui';
   ```
   (Alternativa: defina `BOOTSTRAP_ADMIN_NOME` no `.env` **antes** de criar a
   conta com esse nome — ela já nasce administradora.)
5. Copie a **Service Role Key** (Project Settings → API) para
   `SUPABASE_SERVICE_KEY` no `.env`. Ela é usada pelo back-end para acessar o
   banco sem restrições de RLS. Se preferir usar a `anon key`, configure
   políticas de RLS liberando as tabelas para o back-end.

## Configurando a Groq (IA)

1. Crie uma chave em [console.groq.com](https://console.groq.com/keys).
2. Defina `GROQ_API_KEY` no `.env`.
3. `GROQ_MODEL` já vem com um modelo DeepSeek padrão — troque livremente por
   qualquer outro modelo disponível na Groq editando só essa variável (toda a
   integração está centralizada em `api/ai_service.py`).

Se a Groq ficar indisponível ou a chave não for configurada, o sistema
continua funcionando normalmente: os cálculos continuam corretos e a IA usa
mensagens de fallback pré-definidas em vez de travar o app.

## Rodando localmente

```bash
python3 -m venv venv
source venv/bin/activate           # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edite o .env com suas chaves reais
# em localhost sem HTTPS, defina SESSION_COOKIE_SECURE=false no .env

python app.py
# app disponível em http://localhost:5000
```

## Publicando no Render

1. Suba este repositório no GitHub.
2. No Render, crie um **Web Service** apontando para o repositório.
3. Configurações sugeridas:
   - **Build command:** `pip install -r requirements.txt`
   - **Start command:** `gunicorn wsgi:app`
4. Em **Environment**, cadastre as mesmas variáveis do `.env.example`
   (`SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `GROQ_API_KEY`, `SECRET_KEY`,
   `FLASK_ENV=production`, `SESSION_COOKIE_SECURE=true`).
5. Deploy. O Render fornece HTTPS automaticamente, então os cookies seguros
   funcionam sem configuração extra.

Um arquivo `render.yaml` já está incluído para deploy via "Blueprint" no
Render, caso prefira.

## Instalar como app (PWA)

O manifest e o service worker já deixam o FinIA instalável:

- **Android/Chrome:** um banner "Instalar o FinIA" aparece automaticamente
  (evento `beforeinstallprompt`), com botão de instalação nativa.
- **iPhone/Safari:** como o iOS não expõe instalação automática, o banner
  mostra a instrução "Toque em Compartilhar → Adicionar à Tela de Início".

## Estrutura de dados (Supabase)

Veja `database/schema.sql` para o schema completo: `usuarios`,
`perfis_financeiros`, `objetivos`, `planos_financeiros`, `gastos`,
`gastos_impulsivos`, `resumos_mensais`, `historico_chat_ia`,
`codigos_acesso` e `logs_acesso` — todos com timestamps automáticos, índices
e chaves estrangeiras com `on delete cascade` onde faz sentido.

## Limitações conhecidas

- Não há recuperação de senha por e-mail (o projeto não usa e-mail, por
  especificação). A recuperação é feita via novo código de acesso emitido
  pelo administrador.
- O "valor economizado" no dashboard é hoje uma estimativa baseada na meta
  mensal calculada; para refletir economia real centavo a centavo seria
  necessário integrar um extrato bancário (fora do escopo desta fase).
