-- ============================================================
-- FinIA — Schema completo para Supabase (Postgres)
-- Execute este arquivo inteiro no SQL Editor do Supabase.
-- ============================================================

create extension if not exists "pgcrypto";

-- Função utilitária para manter "updated_at" sempre atualizado
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- codigos_acesso — cadastrados/administrados pelo admin;
-- necessários para permitir a criação de uma conta.
-- ------------------------------------------------------------
create table if not exists codigos_acesso (
  id uuid primary key default gen_random_uuid(),
  codigo text not null unique,
  ativo boolean not null default true,
  max_usos integer not null default 1,
  usos integer not null default 0,
  criado_por text,
  observacao text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_codigos_acesso_codigo on codigos_acesso (codigo);
drop trigger if exists trg_codigos_acesso_updated on codigos_acesso;
create trigger trg_codigos_acesso_updated before update on codigos_acesso
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- usuarios
-- ------------------------------------------------------------
create table if not exists usuarios (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  nome_normalizado text generated always as (lower(trim(nome))) stored,
  senha_hash text not null,
  codigo_acesso_id uuid references codigos_acesso (id) on delete set null,
  is_admin boolean not null default false,
  status text not null default 'ativo', -- ativo | suspenso
  onboarding_done boolean not null default false,
  ultimo_acesso timestamptz,
  session_token text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists idx_usuarios_nome_normalizado on usuarios (nome_normalizado);
drop trigger if exists trg_usuarios_updated on usuarios;
create trigger trg_usuarios_updated before update on usuarios
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- perfis_financeiros — respostas do onboarding
-- ------------------------------------------------------------
create table if not exists perfis_financeiros (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  salario numeric(12,2) not null default 0,
  vale_alimentacao numeric(12,2) not null default 0,
  contas_fixas numeric(12,2) not null default 0,
  possui_dividas text not null default 'nao',
  objetivo_texto_livre text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_perfis_financeiros_usuario on perfis_financeiros (usuario_id);
drop trigger if exists trg_perfis_updated on perfis_financeiros;
create trigger trg_perfis_updated before update on perfis_financeiros
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- dividas — dívidas ativas/quitadas informadas pelo usuário
-- ------------------------------------------------------------
create table if not exists dividas (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  nome text not null,
  valor numeric(12,2) not null default 0,
  ativa boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_dividas_usuario on dividas (usuario_id);
drop trigger if exists trg_dividas_updated on dividas;
create trigger trg_dividas_updated before update on dividas
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- objetivos
-- ------------------------------------------------------------
create table if not exists objetivos (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  titulo text not null,
  prazo_meses integer not null default 6,
  valor_meta numeric(12,2) not null default 0,
  valor_atual numeric(12,2) not null default 0,
  status text not null default 'ativo', -- ativo | concluido | pausado
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_objetivos_usuario on objetivos (usuario_id);
drop trigger if exists trg_objetivos_updated on objetivos;
create trigger trg_objetivos_updated before update on objetivos
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- planos_financeiros — gerado pelo sistema (cálculo) + narrado pela IA
-- ------------------------------------------------------------
create table if not exists planos_financeiros (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  objetivo_id uuid references objetivos (id) on delete set null,
  entradas numeric(12,2) not null default 0,
  saidas_estimadas numeric(12,2) not null default 0,
  reserva_sugerida numeric(12,2) not null default 0,
  meta_mensal numeric(12,2) not null default 0,
  disponivel_lazer numeric(12,2) not null default 0,
  disponivel_economia numeric(12,2) not null default 0,
  checklist jsonb not null default '[]'::jsonb,
  mensagem_ia text,
  versao integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_planos_usuario on planos_financeiros (usuario_id);
drop trigger if exists trg_planos_updated on planos_financeiros;
create trigger trg_planos_updated before update on planos_financeiros
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- gastos
-- ------------------------------------------------------------
create table if not exists gastos (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  descricao text not null,
  categoria text not null default 'Outros',
  valor numeric(12,2) not null,
  data_gasto date not null default current_date,
  origem text not null default 'manual', -- manual | chat_ia
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_gastos_usuario on gastos (usuario_id);
create index if not exists idx_gastos_usuario_data on gastos (usuario_id, data_gasto);
drop trigger if exists trg_gastos_updated on gastos;
create trigger trg_gastos_updated before update on gastos
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- gastos_impulsivos
-- ------------------------------------------------------------
create table if not exists gastos_impulsivos (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  descricao text not null,
  valor numeric(12,2) not null,
  gatilho text, -- o que motivou a compra (opcional, texto livre do usuário)
  data_gasto date not null default current_date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_gastos_impulsivos_usuario on gastos_impulsivos (usuario_id);
drop trigger if exists trg_gastos_impulsivos_updated on gastos_impulsivos;
create trigger trg_gastos_impulsivos_updated before update on gastos_impulsivos
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- resumos_mensais
-- ------------------------------------------------------------
create table if not exists resumos_mensais (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  ano integer not null,
  mes integer not null,
  total_entradas numeric(12,2) not null default 0,
  total_gastos numeric(12,2) not null default 0,
  total_gastos_impulsivos numeric(12,2) not null default 0,
  total_economizado numeric(12,2) not null default 0,
  pontuacao_financeira integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (usuario_id, ano, mes)
);
create index if not exists idx_resumos_usuario on resumos_mensais (usuario_id);
drop trigger if exists trg_resumos_updated on resumos_mensais;
create trigger trg_resumos_updated before update on resumos_mensais
  for each row execute function set_updated_at();

-- ------------------------------------------------------------
-- historico_chat_ia
-- ------------------------------------------------------------
create table if not exists historico_chat_ia (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references usuarios (id) on delete cascade,
  autor text not null, -- 'user' | 'ia'
  mensagem text not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_historico_usuario on historico_chat_ia (usuario_id, created_at);

-- ------------------------------------------------------------
-- logs_acesso
-- ------------------------------------------------------------
create table if not exists logs_acesso (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid references usuarios (id) on delete cascade,
  evento text not null, -- login_sucesso | login_falha | logout | cadastro
  ip text,
  user_agent text,
  created_at timestamptz not null default now()
);
create index if not exists idx_logs_usuario on logs_acesso (usuario_id);
create index if not exists idx_logs_created on logs_acesso (created_at);

-- ============================================================
-- Fim do schema.
-- Dica: cadastre pelo menos um código de acesso para poder criar
-- a primeira conta:
--
--   insert into codigos_acesso (codigo, max_usos) values ('BEMVINDO2026', 5);
--
-- E, depois de criar seu usuário administrador, promova-o com:
--
--   update usuarios set is_admin = true where nome_normalizado = 'seu nome aqui';
-- ============================================================
