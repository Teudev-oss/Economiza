"""Camada única de conexão com o Supabase.

Todo o resto do sistema deve importar `get_client()` daqui — nunca criar
outra instância do client em outro arquivo. Isso mantém a conexão
centralizada e facilita trocar de biblioteca/versão no futuro.
"""
import logging
from supabase import create_client, Client
from flask import current_app, g

logger = logging.getLogger("finia.database")


class SupabaseNotConfiguredError(RuntimeError):
    """Levantado quando SUPABASE_URL / chave não foram configurados no .env."""


def _build_client() -> Client:
    url = current_app.config.get("SUPABASE_URL")
    key = current_app.config.get("SUPABASE_SERVICE_KEY") or current_app.config.get("SUPABASE_ANON_KEY")

    if not url or not key:
        raise SupabaseNotConfiguredError(
            "SUPABASE_URL e SUPABASE_SERVICE_KEY (ou SUPABASE_ANON_KEY) precisam estar "
            "definidos no arquivo .env antes de iniciar o sistema."
        )
    return create_client(url, key)


def get_client() -> Client:
    """Retorna o client do Supabase, reaproveitando a mesma instância durante o request."""
    if "supabase_client" not in g:
        g.supabase_client = _build_client()
    return g.supabase_client


def safe_call(fn, *, default=None, log_label="supabase"):
    """Executa uma chamada ao Supabase capturando e logando erros de conexão.

    Evita que uma falha momentânea do banco derrube o processo inteiro com um
    stack trace cru — devolve `default` e loga o problema.
    """
    try:
        return fn()
    except SupabaseNotConfiguredError:
        raise
    except Exception as exc:  # noqa: BLE001 - queremos capturar qualquer erro de rede/driver
        logger.error("Erro ao acessar Supabase [%s]: %s", log_label, exc)
        return default
