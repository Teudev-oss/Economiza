/* ============================================
   FinIA — Service Worker (PWA)
   Cache básico "app-shell" para navegação offline
   do protótipo. Preparado para evoluir junto com
   o back-end (Flask + Supabase) nas próximas fases.
   ============================================ */
const CACHE_NAME = 'finia-cache-v2';

const APP_SHELL = [
  '/', '/login.html', '/index.html', '/manifest.json',
  '/css/variables.css', '/css/base.css', '/css/components.css', '/css/animations.css',
  '/css/login.css', '/css/dashboard.css',
  '/js/icons.js', '/js/api.js', '/js/main.js', '/js/login.js', '/js/dashboard.js', '/js/pwa.js',
  '/pages/onboarding.html', '/pages/registrar-gasto.html', '/pages/meu-plano.html',
  '/pages/evolucao.html', '/pages/chat.html', '/pages/perfil.html', '/pages/gastos-impulso.html',
  '/assets/icons/icon-192.png', '/assets/icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .catch(() => { /* Evita falha total se algum asset opcional não existir */ })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

/* Estratégia: cache-first para assets estáticos, network-first para navegação */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if(request.method !== 'GET') return;

  const url = new URL(request.url);
  if(url.pathname.startsWith('/api/')){
    // Dados financeiros nunca devem vir do cache — sempre busca na rede.
    event.respondWith(fetch(request));
    return;
  }

  if(request.mode === 'navigate'){
    event.respondWith(
      fetch(request).catch(() => caches.match(request).then((r) => r || caches.match('/index.html')))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if(cached) return cached;
      return fetch(request).then((response) => {
        if(response && response.status === 200 && response.type === 'basic'){
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return response;
      }).catch(() => cached);
    })
  );
});
