/* ============================================
   FinIA — Utilidades compartilhadas do front-end
   ============================================ */

/* Formata número em Real brasileiro */
function formatBRL(value){
  return value.toLocaleString('pt-BR', { style:'currency', currency:'BRL' });
}

/* Injeta a barra de navegação inferior, marcando o item ativo */
function renderBottomNav(active){
  const nav = document.getElementById('bottom-nav');
  if(!nav) return;
  const base = isPageInFolder() ? '' : 'pages/';
  const toRoot = isPageInFolder() ? '../' : '';

  const items = [
    { id:'home', label:'Início', href: '/', icon:'home' },
    { id:'plano', label:'Meu Plano', href: toRoot + 'pages/meu-plano.html', icon:'plan' },
    { id:'fab', label:'', href: toRoot + 'pages/registrar-gasto.html', icon:'plus', fab:true },
    { id:'evolucao', label:'Evolução', href: toRoot + 'pages/evolucao.html', icon:'chart' },
    { id:'chat', label:'Porquinho', href: toRoot + 'pages/chat.html', icon:'piggy' },
  ];

  nav.innerHTML = items.map(it => {
    if(it.fab){
      return `<a class="nav-item nav-fab" href="${it.href}" aria-label="Registrar gasto">
        <span class="btn-fab">${icon('plus', 24)}</span>
      </a>`;
    }
    return `<a class="nav-item ${active===it.id?'active':''}" href="${it.href}">
      ${icon(it.icon, 22)}
      <span>${it.label}</span>
    </a>`;
  }).join('');
}

function isPageInFolder(){
  return window.location.pathname.includes('/pages/');
}

/* Toast simples */
function showToast(message){
  let toast = document.querySelector('.toast');
  if(!toast){
    toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span class="dot"></span><span class="toast-msg"></span>`;
    document.body.appendChild(toast);
  }
  toast.querySelector('.toast-msg').textContent = message;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 2600);
}

/* Transição leve entre páginas ao clicar em links internos */
function initPageTransitions(){
  document.querySelectorAll('a[href$=".html"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if(link.target === '_blank' || e.metaKey || e.ctrlKey) return;
      e.preventDefault();
      document.body.style.transition = 'opacity 180ms ease';
      document.body.style.opacity = '0';
      setTimeout(() => { window.location.href = href; }, 170);
    });
  });
}

/* Protege páginas internas. O servidor já bloqueia o acesso via sessão
   (Flask redireciona para o login antes mesmo de enviar o HTML), então isto
   é apenas uma checagem extra de segurança para o caso da sessão expirar
   enquanto a página já está aberta no navegador. */
function requireLogin(){
  Api.get('/api/auth/me').then(({ data }) => {
    if(!data || !data.autenticado){
      const toRoot = isPageInFolder() ? '../' : '';
      window.location.href = toRoot + 'login.html';
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.body.style.opacity = '0';
  requestAnimationFrame(() => {
    document.body.style.transition = 'opacity 220ms ease';
    document.body.style.opacity = '1';
  });
  initPageTransitions();
});
