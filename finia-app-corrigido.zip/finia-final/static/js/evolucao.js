/* ============================================
   FinIA — Lógica da página Evolução (dados reais via API)
   Gráficos construídos manualmente (SVG/CSS), sem bibliotecas externas.
   ============================================ */
requireLogin();
document.getElementById('back-btn').innerHTML = icon('arrowLeft', 18);
renderBottomNav('evolucao');

const PALETA = ['#a855f7', '#7c3aed', '#c4b5fd', '#5b21b6', '#3ddc97', '#ec4899', '#f472b6'];

function renderLineChart(meses, economiaMensal){
  const w = 320, h = 130, padX = 10, padY = 14;
  const max = Math.max(...economiaMensal, 1);
  const min = Math.min(...economiaMensal, 0);
  const stepX = (w - padX * 2) / Math.max(economiaMensal.length - 1, 1);

  const points = economiaMensal.map((v, i) => {
    const x = padX + i * stepX;
    const y = h - padY - ((v - min) / (max - min || 1)) * (h - padY * 2);
    return { x, y, v };
  });

  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  const areaPath = points.length ? `${linePath} L ${points[points.length-1].x} ${h} L ${points[0].x} ${h} Z` : '';

  document.getElementById('line-path').setAttribute('d', linePath);
  document.getElementById('line-area').setAttribute('d', areaPath);

  document.getElementById('line-points').innerHTML = points.map(p =>
    `<circle class="line-point" cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4"></circle>`
  ).join('');

  document.getElementById('line-labels').innerHTML = meses.map(m => `<span>${escapeHtml(m)}</span>`).join('');
}

function renderBarsChart(meses, gastoMensal){
  const max = Math.max(...gastoMensal, 1);
  const container = document.getElementById('bars-chart');
  container.innerHTML = meses.map((m, i) => {
    const pct = Math.round((gastoMensal[i] / max) * 100);
    const isPeak = gastoMensal[i] === max && max > 0;
    return `<div class="bar-col ${isPeak ? 'peak' : ''}">
      <span class="bar-value">${(gastoMensal[i]/1000).toFixed(1)}k</span>
      <div class="bar-fill" style="height:${pct}%"></div>
      <span class="bar-label">${escapeHtml(m)}</span>
    </div>`;
  }).join('');
}

function renderDonut(categorias){
  const svg = document.getElementById('donut-svg');
  const legend = document.getElementById('donut-legend');
  const total = categorias.reduce((s, c) => s + c.valor, 0);

  if(!categorias.length || total === 0){
    svg.innerHTML = `<circle cx="60" cy="60" r="50" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="16"/>`;
    legend.innerHTML = `<p class="text-sm text-secondary">Nenhum gasto registrado neste mês ainda.</p>`;
    return;
  }

  const radius = 50, cx = 60, cy = 60, circumference = 2 * Math.PI * radius;
  let offsetAcc = 0;
  let segments = `<circle cx="${cx}" cy="${cy}" r="${radius}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="16"/>`;

  categorias.forEach((c, i) => {
    const color = PALETA[i % PALETA.length];
    const fraction = c.valor / total;
    const dash = fraction * circumference;
    const gap = circumference - dash;
    segments += `<circle class="donut-segment" cx="${cx}" cy="${cy}" r="${radius}" fill="none"
      stroke="${color}" stroke-width="16"
      stroke-dasharray="${dash} ${gap}"
      stroke-dashoffset="${-offsetAcc}"
      transform="rotate(-90 ${cx} ${cy})"
      style="animation: fadeIn .6s ease ${i * 0.1}s both;"
    />`;
    offsetAcc += dash;
  });
  svg.innerHTML = segments;

  legend.innerHTML = categorias.map((c, i) => {
    const pct = Math.round((c.valor / total) * 100);
    const color = PALETA[i % PALETA.length];
    return `<div class="legend-item">
      <span class="legend-dot" style="background:${color}"></span>
      <span class="lbl">${escapeHtml(c.label)}</span>
      <span class="pct">${pct}%</span>
    </div>`;
  }).join('');
}

async function carregarEvolucao(){
  const { ok, data } = await Api.get('/api/evolucao');
  if(!ok){
    showToast('Não foi possível carregar sua evolução agora.');
    return;
  }
  // Antes esses 3 números eram fixos no HTML ("R$1.240", "+18%", "782") e
  // nunca mudavam — agora vêm calculados a partir dos dados reais do usuário.
  document.getElementById('stat-economizado').textContent = formatBRL(data.total_economizado_periodo || 0);
  const variacao = data.variacao_percent || 0;
  document.getElementById('stat-variacao').textContent = `${variacao > 0 ? '+' : ''}${variacao}%`;
  document.getElementById('stat-pontuacao').textContent = data.pontuacao || 0;

  renderLineChart(data.meses, data.economia_mensal);
  renderBarsChart(data.meses, data.gasto_mensal);
  renderDonut(data.categorias || []);
}

carregarEvolucao();
