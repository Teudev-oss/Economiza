/* ============================================
   FinIA — Lógica do Onboarding (integrada à API real)
   ============================================ */
document.getElementById('ic-1').innerHTML = icon('user', 16);
document.getElementById('ic-2').innerHTML = icon('wallet', 16);
document.getElementById('ic-3').innerHTML = icon('food', 16);
document.getElementById('ic-4').innerHTML = icon('home2', 16);
document.getElementById('ic-5').innerHTML = icon('card', 16);
document.getElementById('ic-6').innerHTML = icon('target', 16);
document.getElementById('ic-7').innerHTML = icon('calendar', 16);
document.getElementById('ic-8').innerHTML = icon('sparkle', 16);
document.getElementById('loading-orb').innerHTML = icon('piggy', 52);

const TOTAL_STEPS = 8;
let currentStep = 1;
const answers = {};

const progressFill = document.getElementById('progress-fill');
const stepCount = document.getElementById('step-count');
const btnBack = document.getElementById('btn-back');
const btnNext = document.getElementById('btn-next');

function updateProgress(){
  progressFill.style.width = `${(currentStep / TOTAL_STEPS) * 100}%`;
  stepCount.textContent = `${currentStep} / ${TOTAL_STEPS}`;
  btnBack.style.display = currentStep === 1 ? 'none' : 'inline-flex';
  btnNext.textContent = currentStep === TOTAL_STEPS ? 'Finalizar' : 'Continuar';
}

function goToStep(step){
  document.querySelectorAll('.onb-step').forEach(el => el.classList.remove('active'));
  const target = document.querySelector(`.onb-step[data-step="${step}"]`);
  target.classList.add('active');
  currentStep = step;
  updateProgress();
}

/* Seleção de chips (dívidas) */
document.querySelectorAll('.chip-select').forEach(group => {
  group.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if(!chip) return;
    group.querySelectorAll('.chip').forEach(c => c.classList.remove('selected'));
    chip.classList.add('selected');
  });
});

/* Slider de prazo */
const prazoInput = document.getElementById('q-prazo');
const prazoValue = document.getElementById('prazo-value');
prazoInput.addEventListener('input', () => {
  prazoValue.textContent = `${prazoInput.value} ${prazoInput.value == 1 ? 'mês' : 'meses'}`;
});

function validateStep(step){
  if(step === 1) return document.getElementById('q-nome').value.trim().length > 0;
  if(step === 2) return document.getElementById('q-salario').value.trim().length > 0;
  if(step === 5) return document.querySelector('#q-dividas .chip.selected') !== null;
  if(step === 6) return document.getElementById('q-objetivo').value.trim().length > 0;
  return true; // vale, contas, prazo e relato aberto são opcionais / têm valor padrão
}

function collectStep(step){
  if(step === 1) answers.nome = document.getElementById('q-nome').value.trim();
  if(step === 2) answers.salario = document.getElementById('q-salario').value.trim();
  if(step === 3) answers.va = document.getElementById('q-va').value.trim();
  if(step === 4) answers.contas = document.getElementById('q-contas').value.trim();
  if(step === 5) answers.dividas = document.querySelector('#q-dividas .chip.selected')?.dataset.value;
  if(step === 6) answers.objetivo = document.getElementById('q-objetivo').value.trim();
  if(step === 7) answers.prazo = prazoInput.value;
  if(step === 8) answers.objetivoTextoLivre = document.getElementById('q-objetivo-texto').value.trim();
}

btnNext.addEventListener('click', () => {
  if(!validateStep(currentStep)){
    btnNext.style.animation = 'none';
    requestAnimationFrame(() => { btnNext.style.animation = 'pulseGlow .4s'; });
    return;
  }
  collectStep(currentStep);

  if(currentStep === TOTAL_STEPS){
    finishOnboarding();
    return;
  }
  goToStep(currentStep + 1);
});

btnBack.addEventListener('click', () => {
  if(currentStep > 1) goToStep(currentStep - 1);
});

/* Tela final: animação de carregamento enquanto a IA monta o plano de verdade */
function finishOnboarding(){
  document.getElementById('onb-flow').style.display = 'none';
  const loadingScreen = document.getElementById('onb-loading');
  loadingScreen.classList.add('active');

  const messages = [
    'Analisando sua renda...',
    'Calculando contas fixas...',
    'Verificando espaço para economizar...',
    'Montando metas semanais...',
    'Ajustando seu plano personalizado...',
    'Quase pronto!'
  ];
  const msgEl = document.getElementById('loading-msg');
  const bar = document.getElementById('loading-bar');
  let i = 0;

  const interval = setInterval(() => {
    msgEl.style.opacity = '0';
    setTimeout(() => {
      msgEl.textContent = messages[i];
      msgEl.style.opacity = '1';
      bar.style.width = `${((i + 1) / messages.length) * 100}%`;
      i++;
      if(i >= messages.length){
        clearInterval(interval);
      }
    }, 200);
  }, 650);

  salvarOnboarding();
}

async function salvarOnboarding(){
  const payload = {
    nome: answers.nome || 'Usuário',
    salario: answers.salario || '0',
    va: answers.va || '0',
    contas: answers.contas || '0',
    dividas: answers.dividas || 'nao',
    objetivo: answers.objetivo || 'Reserva de emergência',
    prazo: answers.prazo || '8',
    objetivo_texto_livre: answers.objetivoTextoLivre || '',
  };

  const { ok, data } = await Api.post('/api/onboarding', payload);

  // Garante um tempo mínimo de animação (~4s) mesmo se a API responder rápido
  setTimeout(() => {
    if(!ok){
      showToast((data && data.erro) || 'Não foi possível montar seu plano agora. Tente novamente.');
      document.getElementById('onb-loading').classList.remove('active');
      document.getElementById('onb-flow').style.display = '';
      return;
    }
    window.location.href = '/';
  }, 4200);
}

updateProgress();
