/* ============================================
   FinIA — Cliente da API real (substitui o FiniaStore fake)
   ============================================ */
const Api = {
  csrfToken(){
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') : '';
  },

  async _request(method, url, body){
    const options = {
      method,
      credentials: 'same-origin',
      headers: { 'Accept': 'application/json' },
    };
    if(method !== 'GET'){
      options.headers['Content-Type'] = 'application/json';
      options.headers['X-CSRFToken'] = this.csrfToken();
      if(body !== undefined) options.body = JSON.stringify(body);
    }
    let res;
    try{
      res = await fetch(url, options);
    }catch(err){
      return { ok: false, status: 0, data: { ok: false, erro: 'Falha de conexão. Verifique sua internet.' } };
    }
    let data = {};
    try{ data = await res.json(); }catch(err){ data = {}; }
    if(res.status === 401 && !url.includes('/api/auth/')){
      window.location.href = (window.location.pathname.includes('/pages/') ? '../' : '') + 'login.html';
    }
    return { ok: res.ok, status: res.status, data };
  },

  get(url){ return this._request('GET', url); },
  post(url, body){ return this._request('POST', url, body || {}); },
};

/* Escapa texto do usuário antes de inserir via innerHTML (proteção XSS no front-end) */
function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}
