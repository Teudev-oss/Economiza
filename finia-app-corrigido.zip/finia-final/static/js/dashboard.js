/* ============================================
   FinIA — Lógica do Dashboard (dados reais via API)
   ============================================ */
requireLogin();

document.getElementById('ic-bell').innerHTML = icon('bell', 20);
document.getElementById('ic-wallet').innerHTML = icon('wallet', 18);
document.getElementById('qa-1').innerHTML = icon('plus', 20);
document.getElementById('qa-2').innerHTML = icon('plan', 20);
document.getElementById('qa-3').innerHTML = icon('chart', 20);
document.getElementById('qa-4').innerHTML = icon('piggy', 20);
document.getElementById('qa-5').innerHTML = icon('sparkle', 20);
document.getElementById('ic-goal').innerHTML = icon('target', 20);
document.getElementById('ic-in').innerHTML = icon('trend', 18);
document.getElementById('ic-out').innerHTML = icon('wallet', 18);
document.getElementById('ic-fixed').innerHTML = icon('home2', 18);
document.getElementById('ic-free').innerHTML = icon('sparkle', 18);
document.getElementById('piggy-icon').innerHTML = icon('piggy', 22);

renderBottomNav('home');

function animateNumber(el, target, duration){
  const start = performance.now();
  function tick(now){
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(eased * target);
    if(progress < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

async function carregarDashboard(){
  const meRes = await Api.get('/api/auth/me');
  const nome = (meRes.data && meRes.data.nome) || 'Usuário';

  const { ok, data } = await Api.get('/api/dashboard');
  if(!ok){
    showToast((data && data.erro) || 'Não foi possível carregar seus dados agora.');
    return;
  }

  /* Saudação dinâmica */
  const hour = new Date().getHours();
  const timeGreeting = hour < 12 ? 'Bom dia,' : hour < 18 ? 'Boa tarde,' : 'Boa noite,';
  document.getElementById('greeting-time').textContent = timeGreeting;
  document.getElementById('greeting-name').textContent = `${nome.split(' ')[0]} 👋`;
  document.getElementById('header-avatar').textContent = nome.charAt(0).toUpperCase();

  /* Saldo e economia */
  document.getElementById('balance-value').textContent = formatBRL(data.saldo);
  document.getElementById('saved-value').textContent = formatBRL(data.economizado);
  document.getElementById('score-mini').textContent = `${data.pontuacao} pts`;

  /* Score ring */
  const circumference = 2 * Math.PI * 38;
  const scorePercent = Math.min(data.pontuacao / 1000, 1);
  const circle = document.getElementById('score-circle');
  const scoreNumber = document.getElementById('score-number');
  setTimeout(() => {
    circle.style.strokeDashoffset = circumference - circumference * scorePercent;
  }, 300);
  animateNumber(scoreNumber, data.pontuacao, 1200);

  /* Texto da saúde financeira — antes era um texto fixo no HTML que aparecia
     igual pra todo mundo ("Ótimo controle" mesmo com pontuação baixa).
     Agora reflete a pontuação real calculada pelo backend. */
  const scoreTitleEl = document.querySelector('.score-info h3');
  const scoreTextEl = document.querySelector('.score-info p');
  let scoreTitulo, scoreTexto;
  if(data.pontuacao >= 800){
    scoreTitulo = 'Ótimo controle 🎉';
    scoreTexto = 'Seus hábitos financeiros estão consistentes com o seu plano. Continue assim!';
  } else if(data.pontuacao >= 600){
    scoreTitulo = 'Bom controle 👍';
    scoreTexto = 'Você está no caminho certo, mas ainda dá pra melhorar em alguns pontos.';
  } else if(data.pontuacao >= 400){
    scoreTitulo = 'Atenção necessária ⚠️';
    scoreTexto = 'Seus gastos ou dívidas estão pesando no seu plano. Vale revisar sua meta.';
  } else {
    scoreTitulo = 'Hora de reorganizar 🔧';
    scoreTexto = 'Seu plano está bem distante do ideal agora. Vamos ajustar juntos os próximos passos.';
  }
  if(scoreTitleEl) scoreTitleEl.textContent = scoreTitulo;
  if(scoreTextEl) scoreTextEl.textContent = scoreTexto;

  /* Objetivo */
  const objetivo = data.objetivo || {};
  document.getElementById('goal-name').textContent = objetivo.titulo || 'Defina um objetivo';
  document.getElementById('goal-deadline').textContent = objetivo.prazo_meses ? `Meta em ${objetivo.prazo_meses} meses` : '—';
  const goalPercent = Math.round(objetivo.percent || 0);
  document.getElementById('goal-percent').textContent = `${goalPercent}%`;
  document.getElementById('goal-current').textContent = formatBRL(objetivo.valor_atual || 0);
  document.getElementById('goal-target').textContent = `de ${formatBRL(objetivo.valor_meta || 0)}`;
  setTimeout(() => {
    document.getElementById('goal-progress').style.width = `${goalPercent}%`;
  }, 300);

  /* Resumo do mês */
  const resumo = data.resumo_mes || {};
  document.getElementById('sum-in').textContent = formatBRL(resumo.entradas || 0);
  document.getElementById('sum-out').textContent = formatBRL(resumo.gastos || 0);
  document.getElementById('sum-fixed').textContent = formatBRL(resumo.contas_fixas || 0);
  document.getElementById('sum-free').textContent = formatBRL(resumo.disponivel_lazer || 0);

  // Mostra a composição da renda (salário + vale) pra ficar claro de onde
  // vem o total de "Entradas" — evita a impressão de que o valor "aumentou sozinho".
  const detalheEl = document.getElementById('sum-in-detalhe');
  if(resumo.vale_alimentacao > 0){
    detalheEl.textContent = `${formatBRL(resumo.salario || 0)} salário + ${formatBRL(resumo.vale_alimentacao)} vale`;
  } else {
    detalheEl.textContent = '';
  }

  /* Mensagem do Porquinho IA */
  document.getElementById('piggy-tip').innerHTML = escapeHtml(data.mensagem_ia || '');

  /* Vale-alimentação: dinheiro carimbado pra comida, mostrado separado do
     resto — antes ele só era somado ao total de "Entradas" sem explicação. */
  const alim = data.alimentacao || {};
  if(alim.orcamento > 0){
    document.getElementById('alim-restante').textContent = formatBRL(alim.restante || 0);
    const alimPercent = Math.min(Math.round(((alim.gasto_mes || 0) / alim.orcamento) * 100), 100);
    setTimeout(() => { document.getElementById('alim-bar').style.width = `${alimPercent}%`; }, 300);
    document.getElementById('alim-detalhe').textContent =
      `${formatBRL(alim.gasto_mes || 0)} gasto de ${formatBRL(alim.orcamento)} do vale este mês.`;
  } else {
    document.getElementById('card-alimentacao').style.display = 'none';
  }

  /* Dívidas ativas — antes o onboarding perguntava "tem dívida?" e a
     resposta nunca era usada em lugar nenhum. */
  const dividas = data.dividas || { total_ativo: 0, itens: [] };
  document.getElementById('dividas-total').textContent = formatBRL(dividas.total_ativo || 0);
  const listaDividasEl = document.getElementById('dividas-lista');
  if(dividas.itens && dividas.itens.length){
    listaDividasEl.innerHTML = dividas.itens.slice(0, 4).map(d => `
      <div class="flex items-center" style="justify-content:space-between; padding:6px 0;">
        <span class="text-sm text-secondary">${escapeHtml(d.nome)}</span>
        <span class="text-sm" style="font-weight:600;">${formatBRL(d.valor)}</span>
      </div>
    `).join('');
  } else {
    listaDividasEl.innerHTML = '<p class="text-sm text-secondary">Nenhuma dívida ativa registrada 🎉</p>';
  }

  /* Pra onde vai o seu dinheiro: mostra o destino de cada parte do
     salário, incluindo o que ainda não foi alocado — respondendo direto
     a "economizei X, tá bom, mas e o resto?". */
  const aloc = data.alocacao || {};
  const alocacaoEl = document.getElementById('alocacao-lista');
  const linhas = [
    { label: 'Contas fixas', valor: aloc.contas_fixas, cor: 'var(--purple-300)' },
    { label: 'Reserva de emergência', valor: aloc.reserva_sugerida, cor: 'var(--success)' },
    { label: 'Meta de economia', valor: aloc.meta_mensal, cor: '#3ddc97' },
    { label: 'Livre para lazer', valor: aloc.disponivel_lazer, cor: 'var(--warning)' },
  ];
  if((aloc.nao_alocado || 0) > 0){
    linhas.push({ label: 'Ainda sem destino definido', valor: aloc.nao_alocado, cor: 'var(--danger)' });
  }
  alocacaoEl.innerHTML = linhas.map(l => `
    <div class="flex items-center" style="justify-content:space-between; padding:6px 0;">
      <span class="flex items-center gap-12"><span style="width:8px;height:8px;border-radius:50%;background:${l.cor};display:inline-block;"></span><span class="text-sm text-secondary">${l.label}</span></span>
      <span class="text-sm" style="font-weight:600;">${formatBRL(l.valor || 0)}</span>
    </div>
  `).join('');

  if(data.onboarding_pendente){
    showToast('Complete seu onboarding para ver o plano completo.');
  }
}

carregarDashboard();
