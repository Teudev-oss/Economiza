/* ============================================
   FinIA — Lógica do Painel Administrativo (dados reais via API)
   ============================================ */
document.getElementById('adm-mark').innerHTML = icon('piggy', 20);
document.getElementById('nav-ic-1').innerHTML = icon('grid', 18);
document.getElementById('nav-ic-2').innerHTML = icon('users', 18);
document.getElementById('nav-ic-3').innerHTML = icon('clock', 18);
document.getElementById('nav-ic-4').innerHTML = icon('chart', 18);
document.getElementById('nav-ic-5').innerHTML = icon('shield', 18);
document.getElementById('nav-ic-6').innerHTML = icon('arrowLeft', 18);
document.getElementById('ic-live').innerHTML = icon('online', 14);
document.getElementById('ic-users').innerHTML = icon('users', 20);
document.getElementById('ic-online').innerHTML = icon('online', 20);
document.getElementById('ic-clock').innerHTML = icon('clock', 20);
document.getElementById('ic-new').innerHTML = icon('sparkle', 20);
document.getElementById('ic-search').innerHTML = icon('list', 15);
document.getElementById('menu-btn').innerHTML = icon('list', 20);

/* Sidebar mobile */
const sidebar = document.getElementById('adm-sidebar');
const backdrop = document.getElementById('sidebar-backdrop');
document.getElementById('menu-btn').addEventListener('click', () => {
  sidebar.classList.add('open');
  backdrop.classList.add('open');
});
backdrop.addEventListener('click', () => {
  sidebar.classList.remove('open');
  backdrop.classList.remove('open');
});

let usuariosCache = [];

function formatDataHora(iso){
  if(!iso) return { data: '—', hora: '—' };
  const d = new Date(iso);
  return {
    data: d.toLocaleDateString('pt-BR'),
    hora: d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
  };
}

function renderUsers(list){
  const tbody = document.getElementById('user-table-body');
  tbody.innerHTML = list.map(u => {
    const { data, hora } = formatDataHora(u.ultimo_acesso || u.created_at);
    const online = u.ultimo_acesso && (Date.now() - new Date(u.ultimo_acesso).getTime()) < 15 * 60 * 1000;
    return `
    <tr>
      <td>
        <div class="user-cell">
          <span class="avatar">${escapeHtml(u.nome.charAt(0))}</span>
          <span class="name">${escapeHtml(u.nome)}${u.is_admin ? ' 👑' : ''}</span>
        </div>
      </td>
      <td>${data}</td>
      <td>${hora}</td>
      <td><span class="status-dot ${online ? 'online' : 'offline'}">${online ? 'Online' : 'Offline'}</span></td>
      <td><span class="access-code">${u.onboarding_done ? 'Onboarding ok' : 'Pendente'} · ${u.contadores ? u.contadores.gastos : 0} gastos</span></td>
    </tr>`;
  }).join('');
}

async function carregarUsuarios(){
  const { ok, data } = await Api.get('/api/admin/usuarios');
  if(!ok) return;
  usuariosCache = data.usuarios || [];
  renderUsers(usuariosCache);
}

document.getElementById('user-search').addEventListener('input', (e) => {
  const q = e.target.value.toLowerCase();
  renderUsers(usuariosCache.filter(u => u.nome.toLowerCase().includes(q)));
});

function tempoRelativo(iso){
  const diffMin = Math.max(Math.round((Date.now() - new Date(iso).getTime()) / 60000), 0);
  if(diffMin < 1) return 'agora mesmo';
  if(diffMin < 60) return `há ${diffMin} minuto${diffMin>1?'s':''}`;
  const diffH = Math.round(diffMin / 60);
  if(diffH < 24) return `há ${diffH} hora${diffH>1?'s':''}`;
  return `há ${Math.round(diffH/24)} dia(s)`;
}

const EVENTO_TEXTO = {
  login_sucesso: 'fez login',
  login_falha: 'tentou entrar (falhou)',
  logout: 'saiu da conta',
  cadastro: 'criou uma conta',
};

async function carregarAtividade(){
  const { ok, data } = await Api.get('/api/admin/logs');
  if(!ok) return;
  const logs = data.logs || [];
  document.getElementById('activity-list').innerHTML = logs.slice(0, 12).map(l => `
    <div class="activity-item">
      <span class="activity-dot"></span>
      <div>
        <div class="activity-text"><strong>${escapeHtml((l.usuarios && l.usuarios.nome) || 'Alguém')}</strong> ${EVENTO_TEXTO[l.evento] || l.evento}</div>
        <div class="activity-time">${tempoRelativo(l.created_at)}</div>
      </div>
    </div>
  `).join('') || '<p class="text-sm text-secondary">Nenhuma atividade registrada ainda.</p>';
}

function renderCodigos(codigos){
  document.getElementById('codigos-table-body').innerHTML = codigos.map(c => `
    <tr>
      <td><span class="access-code">${escapeHtml(c.codigo)}</span></td>
      <td>${c.usos}/${c.max_usos}</td>
      <td><span class="status-dot ${c.ativo ? 'online' : 'offline'}">${c.ativo ? 'Ativo' : 'Revogado'}</span></td>
      <td>${escapeHtml(c.observacao || '—')}</td>
      <td>${c.ativo ? `<button class="btn-icon revogar-btn" data-id="${c.id}" title="Revogar">✕</button>` : ''}</td>
    </tr>
  `).join('');

  document.querySelectorAll('.revogar-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      await Api.post(`/api/admin/codigos/${btn.dataset.id}/revogar`);
      showToast('Código revogado.');
      carregarCodigos();
      carregarResumo();
    });
  });
}

async function carregarCodigos(){
  const { ok, data } = await Api.get('/api/admin/codigos');
  if(!ok) return;
  renderCodigos(data.codigos || []);
}

document.getElementById('codigo-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const observacao = document.getElementById('codigo-observacao').value.trim();
  const maxUsos = document.getElementById('codigo-max-usos').value || 1;
  const { ok, data } = await Api.post('/api/admin/codigos', { observacao, max_usos: Number(maxUsos) });
  if(!ok){
    showToast((data && data.erro) || 'Não foi possível gerar o código.');
    return;
  }
  showToast(`Código ${data.codigo.codigo} criado!`);
  document.getElementById('codigo-observacao').value = '';
  carregarCodigos();
  carregarResumo();
});

async function carregarResumo(){
  const [resumoRes, codigosRes, logsRes] = await Promise.all([
    Api.get('/api/admin/resumo'),
    Api.get('/api/admin/codigos'),
    Api.get('/api/admin/logs'),
  ]);
  if(resumoRes.ok){
    document.getElementById('stat-total-usuarios').textContent = resumoRes.data.total_usuarios;
    document.getElementById('stat-online').textContent = resumoRes.data.online;
  }
  if(codigosRes.ok){
    const ativos = (codigosRes.data.codigos || []).filter(c => c.ativo).length;
    document.getElementById('stat-codigos-ativos').textContent = ativos;
  }
  if(logsRes.ok){
    document.getElementById('stat-logs').textContent = (logsRes.data.logs || []).length;
  }
}

carregarUsuarios();
carregarAtividade();
carregarCodigos();
carregarResumo();
