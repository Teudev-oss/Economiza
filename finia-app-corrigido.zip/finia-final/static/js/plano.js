/* ============================================
   FinIA — Lógica da página Meu Plano (dados reais via API)
   ============================================ */
requireLogin();
document.getElementById('back-btn').innerHTML = icon('arrowLeft', 18);
document.getElementById('tip-icon').innerHTML = icon('sparkle', 18);
renderBottomNav('plano');

let planoAtualId = null;

/* Tabs */
document.querySelectorAll('.plan-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.plan-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const isMensal = tab.dataset.tab === 'mensal';
    document.getElementById('tab-mensal').style.display = isMensal ? 'block' : 'none';
    document.getElementById('tab-semanal').style.display = isMensal ? 'none' : 'block';
  });
});

function renderChecklist(checklist){
  const container = document.getElementById('checklist');
  container.innerHTML = checklist.map(item => `
    <div class="check-item ${item.done ? 'done' : ''}" data-id="${escapeHtml(item.id)}">
      <span class="check-circle">${item.done ? icon('check', 13) : ''}</span>
      <span class="check-text">${escapeHtml(item.texto)}</span>
    </div>
  `).join('');

  container.querySelectorAll('.check-item').forEach(el => {
    el.addEventListener('click', async () => {
      const nowDone = !el.classList.contains('done');
      el.classList.toggle('done', nowDone);
      el.querySelector('.check-circle').innerHTML = nowDone ? icon('check', 13) : '';
      await Api.post('/api/plano/checklist', { plano_id: planoAtualId, item_id: el.dataset.id, done: nowDone });
    });
  });
}

async function carregarPlano(){
  const { ok, data } = await Api.get('/api/plano');
  if(!ok || !data.plano){
    showToast('Você ainda não tem um plano. Complete o onboarding primeiro.');
    setTimeout(() => { window.location.href = 'onboarding.html'; }, 1500);
    return;
  }

  const plano = data.plano;
  const objetivo = data.objetivo || {};
  planoAtualId = plano.id;

  document.getElementById('plan-goal-title').textContent = objetivo.titulo || 'Seu objetivo';
  document.getElementById('plan-goal-sub').textContent = `Plano de ${objetivo.prazo_meses || '-'} meses`;

  const metaValor = objetivo.valor_meta || 0;
  const metaAtual = objetivo.valor_atual || 0;
  const planPercent = metaValor ? Math.min(Math.round((metaAtual / metaValor) * 100), 100) : 0;
  document.getElementById('plan-progress-label').textContent = `${planPercent}%`;
  document.getElementById('plan-status').textContent = planPercent >= 100 ? 'Concluído' : 'Em dia';
  setTimeout(() => { document.getElementById('plan-progress').style.width = `${planPercent}%`; }, 250);

  document.getElementById('meta-mensal-valor').textContent = formatBRL(plano.meta_mensal || 0);
  const economizadoReal = data.economizado_real ?? plano.disponivel_economia ?? 0;
  const mensalPercent = plano.meta_mensal ? Math.min(Math.round((economizadoReal / plano.meta_mensal) * 100), 100) : 0;
  document.getElementById('meta-mensal-pct').textContent = `${mensalPercent}%`;
  document.getElementById('meta-mensal-atual').textContent = formatBRL(economizadoReal);
  setTimeout(() => { document.getElementById('meta-mensal-bar').style.width = `${mensalPercent}%`; }, 250);

  renderChecklist(plano.checklist || []);

  document.getElementById('tip-texto').textContent = plano.mensagem_ia || 'Continue registrando seus gastos para receber dicas personalizadas.';

  await carregarSemana(plano);
}

async function carregarSemana(plano){
  const { ok, data } = await Api.get('/api/gastos');
  const dias = ['S','T','Q','Q','S','S','D'];
  const hoje = new Date();
  const inicioSemana = new Date(hoje);
  inicioSemana.setDate(hoje.getDate() - ((hoje.getDay() + 6) % 7)); // segunda-feira
  inicioSemana.setHours(0,0,0,0);

  const porDia = [0,0,0,0,0,0,0];
  if(ok && data.gastos){
    data.gastos.forEach(g => {
      const d = new Date(g.data_gasto + 'T00:00:00');
      const diffDias = Math.floor((d - inicioSemana) / 86400000);
      if(diffDias >= 0 && diffDias < 7) porDia[diffDias] += Number(g.valor || 0);
    });
  }

  const limiteDia = plano ? Math.max((plano.disponivel_lazer || 0) / 7, 1) : 70;
  const maxValor = Math.max(...porDia, limiteDia, 1);
  const weekBars = document.getElementById('week-bars');
  weekBars.innerHTML = dias.map((d, i) => {
    const h = Math.min((porDia[i] / (maxValor * 1.3)) * 100, 100);
    const cls = porDia[i] > limiteDia ? 'over' : 'under';
    return `<div class="week-bar">
      <div class="bar ${cls}" style="height:${h}%"></div>
      <span>${d}</span>
    </div>`;
  }).join('');

  const totalSemana = porDia.reduce((a,b) => a+b, 0);
  const limiteSemana = limiteDia * 7;
  const semanalPercent = limiteSemana ? Math.min(Math.round((totalSemana / limiteSemana) * 100), 100) : 0;
  document.getElementById('meta-semanal-valor').textContent = formatBRL(limiteSemana);
  document.getElementById('meta-semanal-pct').textContent = `${semanalPercent}%`;
  document.getElementById('meta-semanal-restante').textContent = formatBRL(Math.max(limiteSemana - totalSemana, 0));
  setTimeout(() => { document.getElementById('meta-semanal-bar').style.width = `${semanalPercent}%`; }, 250);
}

carregarPlano();
