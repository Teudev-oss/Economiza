/* ============================================
   FinIA — Service Worker + Botão de instalação (PWA)
   Funciona tanto no Android/Chrome (prompt nativo)
   quanto no iPhone/Safari (instrução "Adicionar à Tela de Início",
   já que o iOS não expõe o evento beforeinstallprompt).
   ============================================ */
if('serviceWorker' in navigator){
  window.addEventListener('load', () => {
    const swPath = window.location.pathname.includes('/pages/') ? '../service-worker.js' : './service-worker.js';
    navigator.serviceWorker.register(swPath).catch(() => {
      /* Silencioso: o app continua funcionando normalmente sem cache offline */
    });
  });
}

(function initInstallBanner(){
  const jaInstalado = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  if(jaInstalado) return;
  if(localStorage.getItem('finia_install_dismissed') === '1') return;

  const isIOS = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
  let deferredPrompt = null;

  function buildBanner(){
    const banner = document.createElement('div');
    banner.id = 'pwa-install-banner';
    banner.style.cssText = `
      position:fixed; left:12px; right:12px; bottom:calc(78px + env(safe-area-inset-bottom));
      z-index:9999; display:flex; align-items:center; gap:10px;
      background:rgba(20,16,30,0.96); border:1px solid rgba(255,255,255,0.1);
      backdrop-filter: blur(10px); border-radius:16px; padding:12px 14px;
      box-shadow:0 8px 24px rgba(0,0,0,0.35); font-family:'Inter',sans-serif;
      animation: fadeIn .3s ease both;
    `;
    banner.innerHTML = `
      <span style="font-size:22px; line-height:1;">🐷</span>
      <div style="flex:1; min-width:0;">
        <div style="font-size:13px; font-weight:600; color:#fff;">Instalar o FinIA</div>
        <div id="pwa-install-text" style="font-size:12px; color:rgba(255,255,255,0.6);">Adicione à tela inicial para acesso rápido.</div>
      </div>
      <button id="pwa-install-btn" style="background:linear-gradient(135deg,#a855f7,#ec4899); color:#fff; border:none; border-radius:10px; padding:8px 14px; font-size:13px; font-weight:600; white-space:nowrap;">Instalar</button>
      <button id="pwa-install-close" aria-label="Fechar" style="background:none; border:none; color:rgba(255,255,255,0.4); font-size:16px; padding:2px 4px;">✕</button>
    `;
    document.body.appendChild(banner);

    document.getElementById('pwa-install-close').addEventListener('click', () => {
      localStorage.setItem('finia_install_dismissed', '1');
      banner.remove();
    });

    document.getElementById('pwa-install-btn').addEventListener('click', async () => {
      if(isIOS){
        document.getElementById('pwa-install-text').textContent =
          'Toque em Compartilhar (⬆️) na barra do Safari e depois em "Adicionar à Tela de Início".';
        return;
      }
      if(deferredPrompt){
        deferredPrompt.prompt();
        await deferredPrompt.userChoice;
        deferredPrompt = null;
        localStorage.setItem('finia_install_dismissed', '1');
        banner.remove();
      }
    });

    return banner;
  }

  if(isIOS){
    // iOS: sem evento nativo, mostramos direto a instrução ao tocar em "Instalar".
    setTimeout(buildBanner, 1200);
  } else {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      buildBanner();
    });
  }
})();
