/* ============================================
   FinIA — Lógica da página Perfil (dados reais via API)
   ============================================ */
requireLogin();
document.getElementById('back-btn').innerHTML = icon('arrowLeft', 18);
document.getElementById('edit-badge').innerHTML = icon('edit', 14);
document.getElementById('ic-lock').innerHTML = icon('lock', 18);
document.getElementById('ic-shield').innerHTML = icon('shield', 18);
document.getElementById('ic-bell2').innerHTML = icon('bell', 18);
document.getElementById('ic-logout').innerHTML = icon('logout', 18);
document.getElementById('ic-chev-1').innerHTML = icon('arrowRight', 16);
document.getElementById('ic-chev-2').innerHTML = icon('arrowRight', 16);
document.getElementById('ic-chev-3').innerHTML = icon('arrowRight', 16);
renderBottomNav('perfil');

async function carregarPerfil(){
  const { ok, data } = await Api.get('/api/perfil');
  if(!ok) return;
  document.getElementById('profile-name').textContent = data.nome;
  document.getElementById('profile-goal').textContent = `🎯 Objetivo: ${data.objetivo || 'ainda não definido'}`;
  document.getElementById('avatar-initial').textContent = data.nome.charAt(0).toUpperCase();
  document.getElementById('stat-score').textContent = data.pontuacao;
  document.getElementById('stat-goals').textContent = data.objetivos_ativos;
  document.getElementById('stat-streak').textContent = data.dias_ativos_30d;

  if(data.is_admin){
    const adminLink = document.createElement('a');
    adminLink.href = '../adm.html';
    adminLink.className = 'card menu-item anim-fade-up';
    adminLink.style.marginTop = '12px';
    adminLink.textContent = '🛠️ Painel administrativo';
    document.getElementById('bottom-nav').before(adminLink);
  }
}

/* Modal alterar senha */
const pwModal = document.getElementById('pw-modal');
document.getElementById('open-change-pw').addEventListener('click', () => pwModal.classList.add('open'));
document.getElementById('close-pw').addEventListener('click', () => pwModal.classList.remove('open'));
pwModal.addEventListener('click', (e) => { if(e.target === pwModal) pwModal.classList.remove('open'); });

document.getElementById('pw-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const atual = document.getElementById('pw-atual').value;
  const nova = document.getElementById('pw-nova').value;
  const confirma = document.getElementById('pw-confirma').value;

  if(nova !== confirma){
    showToast('As senhas novas não coincidem.');
    return;
  }

  const { ok, data } = await Api.post('/api/perfil/senha', { senha_atual: atual, senha_nova: nova });
  if(!ok){
    showToast((data && (data.erro || Object.values(data.erros||{})[0])) || 'Não foi possível trocar a senha.');
    return;
  }
  pwModal.classList.remove('open');
  e.target.reset();
  showToast('Senha alterada com sucesso');
});

/* Sair */
document.getElementById('logout-btn').addEventListener('click', async () => {
  await Api.post('/api/auth/logout');
  showToast('Sessão encerrada');
  setTimeout(() => { window.location.href = '../login.html'; }, 700);
});

/* Dívidas */
async function carregarDividas(){
  const { ok, data } = await Api.get('/api/dividas');
  if(!ok) return;
  document.getElementById('perfil-dividas-total').textContent = formatBRL(data.total_ativo || 0);
  const lista = document.getElementById('perfil-dividas-lista');
  const ativas = (data.itens || []).filter(d => d.ativa);
  if(!ativas.length){
    lista.innerHTML = '<p class="text-sm text-secondary">Nenhuma dívida ativa registrada 🎉</p>';
    return;
  }
  lista.innerHTML = ativas.map(d => `
    <div class="flex items-center" style="justify-content:space-between; padding:8px 0; border-bottom:1px solid var(--border-subtle,rgba(255,255,255,.06));">
      <span class="text-sm">${escapeHtml(d.nome)} — <strong>${formatBRL(d.valor)}</strong></span>
      <button type="button" class="btn-quitar" data-id="${d.id}" style="font-size:12px; color:var(--success); background:none; border:none;">Quitar</button>
    </div>
  `).join('');
  lista.querySelectorAll('.btn-quitar').forEach(btn => {
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      const { ok } = await Api.post(`/api/dividas/${btn.dataset.id}/quitar`, {});
      if(ok){
        showToast('Dívida quitada 🎉');
        carregarDividas();
      } else {
        btn.disabled = false;
        showToast('Não foi possível quitar agora.');
      }
    });
  });
}

document.getElementById('divida-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const nome = document.getElementById('divida-nome').value.trim();
  const valorRaw = document.getElementById('divida-valor').value.trim();
  const valor = parseFloat(valorRaw.replace(/\./g, '').replace(',', '.'));

  if(!nome || !valor || valor <= 0){
    showToast('Preencha o nome e um valor válido.');
    return;
  }

  const { ok, data } = await Api.post('/api/dividas', { nome, valor });
  if(!ok){
    showToast((data && (data.erro || Object.values(data.erros||{})[0])) || 'Não foi possível adicionar.');
    return;
  }
  e.target.reset();
  showToast('Dívida adicionada');
  carregarDividas();
});

carregarPerfil();
carregarDividas();
