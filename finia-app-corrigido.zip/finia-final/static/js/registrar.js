/* ============================================
   FinIA — Registrar Gasto (conectado à API real)
   O parsing local é só para o preview instantâneo;
   o valor/categoria que realmente é salvo vem do
   back-end (services/finance_service.py), que é
   a única fonte de verdade para os cálculos.
   ============================================ */
requireLogin();
document.getElementById('back-btn').innerHTML = icon('arrowLeft', 18);
document.getElementById('bubble-avatar-1').innerHTML = icon('piggy', 15);

const categoriasPreview = {
  pizza:'Alimentação', mercado:'Alimentação', restaurante:'Alimentação', lanche:'Alimentação', ifood:'Alimentação',
  uber:'Transporte', gasolina:'Transporte', combustivel:'Transporte', onibus:'Transporte', '99':'Transporte',
  cinema:'Lazer', show:'Lazer', jogo:'Lazer', netflix:'Assinaturas', spotify:'Assinaturas',
  farmacia:'Saúde', remedio:'Saúde', academia:'Saúde',
  roupa:'Vestuário', tenis:'Vestuário',
};

function detectCategoriaPreview(texto){
  const lower = texto.toLowerCase();
  for(const key in categoriasPreview){
    if(lower.includes(key)) return categoriasPreview[key];
  }
  return 'Outros';
}

function detectValorPreview(texto){
  const lower = texto.toLowerCase();
  // Mesma lógica do back-end (finance_service.detectar_valor): prioriza
  // número junto de "R$"/"reais", senão usa o ÚLTIMO número da frase — não
  // o primeiro, pra não confundir quantidade ("2 pizzas") com preço ("45 reais").
  let match = lower.match(/r\$\s*(\d+(?:[.,]\d+)?)/);
  if(!match) match = lower.match(/(\d+(?:[.,]\d+)?)\s*(?:reais|conto|contos)\b/);
  if(match) return parseFloat(match[1].replace(',', '.'));

  const todos = lower.match(/\d+(?:[.,]\d+)?/g);
  if(!todos) return null;
  return parseFloat(todos[todos.length - 1].replace(',', '.'));
}

const form = document.getElementById('rg-form');
const input = document.getElementById('rg-input');
const sendBtn = document.getElementById('rg-send');
const conversation = document.getElementById('rg-conversation');
const body = document.getElementById('rg-body');

sendBtn.innerHTML = icon('send', 18);

input.addEventListener('input', () => {
  sendBtn.disabled = input.value.trim().length === 0;
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 120) + 'px';
});

document.querySelectorAll('.rg-example').forEach(btn => {
  btn.addEventListener('click', () => {
    input.value = btn.dataset.text;
    sendBtn.disabled = false;
    input.focus();
  });
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const texto = input.value.trim();
  if(!texto) return;

  addUserBubble(texto);
  input.value = '';
  sendBtn.disabled = true;
  input.style.height = 'auto';

  const valorPreview = detectValorPreview(texto);
  const categoriaPreview = detectCategoriaPreview(texto);

  setTimeout(() => {
    addParseCard(texto, valorPreview, categoriaPreview);
  }, 400);
});

function addUserBubble(texto){
  const div = document.createElement('div');
  div.className = 'rg-bubble user';
  div.textContent = texto;
  conversation.appendChild(div);
  scrollToBottom();
}

function addParseCard(textoOriginal, valorPreview, categoriaPreview){
  const wrap = document.createElement('div');
  wrap.className = 'rg-bubble piggy';
  wrap.innerHTML = `<span class="bubble-avatar">${icon('piggy',15)}</span><span>Entendi! Confirma os detalhes abaixo:</span>`;
  conversation.appendChild(wrap);

  const card = document.createElement('div');
  card.className = 'card rg-parse-card';
  card.innerHTML = `
    <div class="rg-parse-amount">${valorPreview ? formatBRL(valorPreview) : 'R$ --'}</div>
    <div class="rg-parse-row"><span class="lbl">Categoria</span><span class="val">${escapeHtml(categoriaPreview)}</span></div>
    <div class="rg-parse-row"><span class="lbl">Descrição</span><span class="val">${escapeHtml(textoOriginal)}</span></div>
    <div class="rg-parse-row"><span class="lbl">Data</span><span class="val">${new Date().toLocaleDateString('pt-BR')}</span></div>
    <button class="btn btn-primary mt-16" type="button">Confirmar registro</button>
  `;
  const confirmBtn = card.querySelector('button');
  confirmBtn.addEventListener('click', async function(){
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = `<span class="dots-loading"><span></span><span></span><span></span></span>`;

    const { ok, data } = await Api.post('/api/gastos', { texto: textoOriginal });

    if(!ok){
      confirmBtn.disabled = false;
      confirmBtn.innerHTML = 'Confirmar registro';
      showToast((data && data.erro) || 'Não consegui identificar um valor. Tente incluir o número (ex.: "pizza 45").');
      return;
    }

    confirmBtn.innerHTML = `${icon('check',16)} Registrado!`;
    confirmBtn.style.background = 'var(--success)';
    showToast('Gasto registrado com sucesso 🐷');
  });
  conversation.appendChild(card);
  scrollToBottom();
}

function scrollToBottom(){
  setTimeout(() => { body.scrollTop = body.scrollHeight; }, 60);
}
