/* ============================================
   FinIA — Gastos por Impulso (dados reais via API)
   ============================================ */
requireLogin();
document.getElementById('back-btn').innerHTML = icon('arrowLeft', 18);
document.getElementById('impulso-icon').innerHTML = icon('sparkle', 20);
document.getElementById('tip-icon').innerHTML = icon('sparkle', 18);
renderBottomNav();

const nomesMeses = ['', 'Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

function renderBarsChart(serie){
  const container = document.getElementById('impulso-bars-chart');
  if(!serie.length){
    container.innerHTML = '<p class="text-sm text-secondary">Ainda não há dados suficientes.</p>';
    return;
  }
  const max = Math.max(...serie.map(s => s.total), 1);
  container.innerHTML = serie.map(s => {
    const pct = Math.round((s.total / max) * 100);
    const isPeak = s.total === max && max > 0;
    return `<div class="bar-col ${isPeak ? 'peak' : ''}">
      <span class="bar-value">${formatBRL(s.total)}</span>
      <div class="bar-fill" style="height:${pct}%"></div>
      <span class="bar-label">${nomesMeses[s.mes]}</span>
    </div>`;
  }).join('');
}

function renderLista(itens){
  const container = document.getElementById('impulso-lista');
  if(!itens.length){
    container.innerHTML = '<p class="text-sm text-secondary">Nenhuma compra por impulso registrada ainda.</p>';
    return;
  }
  container.innerHTML = itens.map(i => `
    <div class="impulso-item">
      <div>
        <div class="desc">${escapeHtml(i.descricao)}</div>
        ${i.gatilho ? `<div class="gatilho">💭 ${escapeHtml(i.gatilho)}</div>` : ''}
      </div>
      <div>
        <div class="valor">${formatBRL(i.valor)}</div>
        <div class="data">${new Date(i.data_gasto + 'T00:00:00').toLocaleDateString('pt-BR')}</div>
      </div>
    </div>
  `).join('');
}

async function carregarImpulso(){
  const { ok, data } = await Api.get('/api/gastos-impulso');
  if(!ok){
    showToast('Não foi possível carregar seus gastos por impulso agora.');
    return;
  }
  document.getElementById('impulso-total-mes').textContent = formatBRL(data.total_mes_atual);
  const diff = data.total_mes_atual - data.media_meses_anteriores;
  const comparativo = document.getElementById('impulso-comparativo');
  if(data.media_meses_anteriores === 0){
    comparativo.textContent = 'Ainda não há meses anteriores para comparar.';
  } else if(diff > 0){
    comparativo.textContent = `${formatBRL(diff)} a mais que a média dos meses anteriores (${formatBRL(data.media_meses_anteriores)}).`;
  } else {
    comparativo.textContent = `${formatBRL(Math.abs(diff))} a menos que a média dos meses anteriores. Continue assim!`;
  }

  document.getElementById('impulso-mensagem-ia').innerHTML = escapeHtml(data.mensagem_ia || '');
  renderBarsChart(data.serie_mensal || []);
  renderLista(data.itens_recentes || []);
}

document.getElementById('impulso-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const descricao = document.getElementById('imp-descricao').value.trim();
  const valorRaw = document.getElementById('imp-valor').value.trim();
  const gatilho = document.getElementById('imp-gatilho').value.trim();
  const valor = parseFloat(valorRaw.replace(/\./g, '').replace(',', '.'));

  if(!descricao || !valor || valor <= 0){
    showToast('Preencha a descrição e um valor válido.');
    return;
  }

  const { ok, data } = await Api.post('/api/gastos-impulso', { descricao, valor, gatilho });
  if(!ok){
    showToast((data && (data.erro || Object.values(data.erros||{})[0])) || 'Não foi possível registrar.');
    return;
  }

  showToast('Compra registrada 🐷');
  e.target.reset();
  carregarImpulso();
});

carregarImpulso();
