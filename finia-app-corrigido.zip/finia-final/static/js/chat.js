/* ============================================
   FinIA — Lógica do Chat (conectado à IA real via /api/chat)
   ============================================ */
requireLogin();
document.getElementById('back-btn').innerHTML = icon('arrowLeft', 18);
document.getElementById('chat-avatar').innerHTML = icon('piggy', 22);
document.getElementById('chat-send').innerHTML = icon('send', 18);

const messagesEl = document.getElementById('chat-messages');

function addMessage(who, text, time){
  const row = document.createElement('div');
  row.className = `msg-row ${who}`;
  const avatar = who === 'piggy' ? `<span class="msg-avatar">${icon('piggy', 14)}</span>` : '';
  row.innerHTML = `
    ${avatar}
    <div>
      <div class="msg-bubble">${escapeHtml(text)}</div>
      <div class="msg-time">${time || horaAtual()}</div>
    </div>
  `;
  messagesEl.appendChild(row);
  scrollBottom();
}

function horaAtual(dateStr){
  const d = dateStr ? new Date(dateStr) : new Date();
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

function scrollBottom(){
  setTimeout(() => { messagesEl.scrollTop = messagesEl.scrollHeight; }, 60);
}

function showTyping(){
  const row = document.createElement('div');
  row.className = 'typing-row';
  row.id = 'typing-indicator';
  row.innerHTML = `<span class="msg-avatar">${icon('piggy',14)}</span>
    <div class="typing-bubble"><span class="dots-loading"><span></span><span></span><span></span></span></div>`;
  messagesEl.appendChild(row);
  scrollBottom();
}
function hideTyping(){
  document.getElementById('typing-indicator')?.remove();
}

async function carregarHistorico(){
  const { ok, data } = await Api.get('/api/chat/historico');
  messagesEl.innerHTML = '';
  if(ok && data.mensagens && data.mensagens.length){
    data.mensagens.forEach(m => {
      addMessage(m.autor === 'ia' ? 'piggy' : 'user', m.mensagem, horaAtual(m.created_at));
    });
  } else {
    const meRes = await Api.get('/api/auth/me');
    const nome = (meRes.data && meRes.data.nome) || 'tudo bem';
    addMessage('piggy', `Oi ${nome.split(' ')[0]}! 🐷 Eu sou o Porquinho IA, seu assistente financeiro. Como posso te ajudar hoje?`);
  }
}

async function enviarMensagem(texto){
  addMessage('user', texto);
  showTyping();
  const { ok, data } = await Api.post('/api/chat', { mensagem: texto });
  hideTyping();
  if(!ok){
    addMessage('piggy', (data && (data.erro || Object.values(data.erros||{})[0])) || 'Não consegui responder agora, tente novamente.');
    return;
  }
  addMessage('piggy', data.resposta);
}

const form = document.getElementById('chat-form');
const input = document.getElementById('chat-input');
form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if(!text) return;
  input.value = '';
  enviarMensagem(text);
});

document.querySelectorAll('.suggestion-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    enviarMensagem(chip.textContent.trim());
  });
});

carregarHistorico();
