/* ============================================
   FinIA — Lógica da tela de Login (integrada à API real)
   ============================================ */
document.getElementById('brand-mark').innerHTML = icon('piggy', 38);
document.getElementById('icon-user').innerHTML = icon('user', 18);
document.getElementById('icon-lock').innerHTML = icon('lock', 18);
document.getElementById('icon-key').innerHTML = icon('key', 18);
document.getElementById('icon-arrow').innerHTML = icon('arrowRight', 18);
document.getElementById('icon-modal-user').innerHTML = icon('user', 20);

let senhaVisible = false;
const senhaInput = document.getElementById('senha');
const toggleBtn = document.getElementById('toggle-senha');
toggleBtn.innerHTML = icon('eye', 18);
toggleBtn.addEventListener('click', () => {
  senhaVisible = !senhaVisible;
  senhaInput.type = senhaVisible ? 'text' : 'password';
  toggleBtn.innerHTML = icon(senhaVisible ? 'eyeOff' : 'eye', 18);
});

function mostrarErroForm(form, mensagem){
  let erroEl = form.querySelector('.form-erro');
  if(!erroEl){
    erroEl = document.createElement('p');
    erroEl.className = 'form-erro';
    erroEl.style.cssText = 'color:#ff6b81;font-size:13px;margin-top:8px;';
    form.appendChild(erroEl);
  }
  erroEl.textContent = mensagem;
}

/* Envio do login (real) */
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('submit-btn');
  const nome = document.getElementById('nome').value.trim();
  const senha = senhaInput.value;
  const original = btn.innerHTML;
  btn.innerHTML = `<span class="dots-loading"><span></span><span></span><span></span></span>`;
  btn.disabled = true;

  const { ok, data } = await Api.post('/api/auth/login', { nome, senha });

  if(!ok){
    btn.innerHTML = original;
    btn.disabled = false;
    mostrarErroForm(e.target, (data && (data.erro || Object.values(data.erros || {})[0])) || 'Não foi possível entrar.');
    return;
  }

  window.location.href = data.onboarding_done ? '/' : 'pages/onboarding.html';
});

/* Modal: criar conta */
const signupModal = document.getElementById('signup-modal');
document.getElementById('open-signup').addEventListener('click', () => signupModal.classList.add('open'));
document.getElementById('close-signup').addEventListener('click', () => signupModal.classList.remove('open'));
signupModal.addEventListener('click', (e) => { if(e.target === signupModal) signupModal.classList.remove('open'); });

document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const nome = document.getElementById('s-nome').value.trim();
  const senha = document.getElementById('s-senha').value;
  const codigo = document.getElementById('s-codigo').value.trim();
  const btn = e.target.querySelector('button[type="submit"]');
  const original = btn.innerHTML;
  btn.disabled = true;

  const { ok, data } = await Api.post('/api/auth/registrar', { nome, senha, codigo_acesso: codigo });

  btn.disabled = false;
  if(!ok){
    mostrarErroForm(e.target, (data && (data.erro || Object.values(data.erros || {})[0])) || 'Não foi possível criar a conta.');
    return;
  }

  showToast('Conta criada com sucesso!');
  setTimeout(() => { window.location.href = 'pages/onboarding.html'; }, 700);
});

/* Modal: esqueci minha senha (sem e-mail no sistema — orienta a pedir novo código) */
const forgotModal = document.getElementById('forgot-modal');
document.getElementById('forgot-btn').addEventListener('click', () => forgotModal.classList.add('open'));
document.getElementById('close-forgot').addEventListener('click', () => forgotModal.classList.remove('open'));
forgotModal.addEventListener('click', (e) => { if(e.target === forgotModal) forgotModal.classList.remove('open'); });
document.getElementById('forgot-form').addEventListener('submit', (e) => {
  e.preventDefault();
  forgotModal.classList.remove('open');
  showToast('Fale com o administrador para receber um novo código de acesso.');
});
