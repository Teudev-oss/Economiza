"""Configuração central da aplicação FinIA.

Todas as variáveis sensíveis vêm do arquivo .env (nunca hardcode segredos aqui).
"""
import os
from dotenv import load_dotenv

load_dotenv()


def _bool_env(name, default="false"):
    return os.getenv(name, default).strip().lower() in ("1", "true", "yes", "on")


class Config:
    # --- Flask / sessão ---
    SECRET_KEY = os.getenv("SECRET_KEY")
    if not SECRET_KEY:
        # Em desenvolvimento local geramos uma chave temporária para não travar o boot,
        # mas isso invalida sessões a cada reinício — sempre defina SECRET_KEY em produção.
        import secrets
        SECRET_KEY = secrets.token_hex(32)

    FLASK_ENV = os.getenv("FLASK_ENV", "production")
    DEBUG = FLASK_ENV == "development"

    # --- Cookies seguros ---
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool_env("SESSION_COOKIE_SECURE", "true")
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 30  # 30 dias (recuperação de sessão)
    SESSION_REFRESH_EACH_REQUEST = True

    # --- CSRF ---
    WTF_CSRF_TIME_LIMIT = None
    WTF_CSRF_SSL_STRICT = _bool_env("SESSION_COOKIE_SECURE", "true")

    # --- Supabase ---
    SUPABASE_URL = os.getenv("SUPABASE_URL", "")
    SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "")
    SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "")

    # --- Groq / DeepSeek (IA) ---
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL = os.getenv("GROQ_MODEL", "deepseek-r1-distill-llama-70b")

    # --- Bootstrap ---
    BOOTSTRAP_ACCESS_CODE = os.getenv("BOOTSTRAP_ACCESS_CODE", "").strip()
    BOOTSTRAP_ADMIN_NOME = os.getenv("BOOTSTRAP_ADMIN_NOME", "").strip()

    # --- Rate limit ---
    RATELIMIT_STORAGE_URI = os.getenv("RATELIMIT_STORAGE_URI", "memory://")
